#pragma once
#include <vector>
#include <algorithm>
#include <iostream>
#include <stack>

#include "Constants.h"
#include "Node.h"
#include "Edge.h"

class Graph {
	using C = Constants;
	using AdjacencyMatrix = std::vector<std::vector<bool>>;
	using AdjacencyLists = std::vector<std::vector<int>>;
	using CostMatrix = std::vector<std::vector<float>>;
	using ConnectedComponents = std::vector<std::vector<Node>>;

public:
	Graph();

	bool Directed() const;
	bool Weighted() const;
	std::vector<Node> Nodes() const;
	std::vector<Edge> Edges() const;
	
	Node MoveableNode() const;
	void SetMoveableNode(Node& node);
	void MoveNode(const unsigned int& x, const unsigned int& y);

	void AddNode(const unsigned int x, const unsigned int y, const int val);
	void RemoveNode(Node& node);

	void MakeEdge(const Node& start, const Node& other, bool directed, float weight);

	std::vector<Edge> Traverse(const int algorithm);

	void PrintAdjacencyMatrix();
	void PrintCostMatrix();
	void PrintAdjacencyLists();
	void PrintConnectedComponents();

	void Clear();

	void UpdateAdjacencyMatrix();
	void UpdateAdjacencyLists();
	void UpdateConnectedComponents();

	std::vector<Edge> Kruskal();
private:
	size_t _IndexOf(const Node& node) const;

	void _DFS(size_t nodeIndex, std::vector<bool>& visited, std::vector<Node>& component);
	std::vector<Node> _Neighbors(size_t nodeIndex) const;

public:
	Node MOVEABLE_NODE;
	Node EDGE_START_NODE;
	Node EDGE_END_NODE;
	float CURRENT_WEIGHT = C::UNITIALIZED_WEIGHT;

private:
	bool m_directed;
	bool m_weighted;

	std::vector<Node> m_nodes;
	std::vector<Edge> m_edges;

	AdjacencyMatrix m_adjacencyMatrix;

	AdjacencyLists m_adjacencyLists;

	CostMatrix m_costMatrix;

	ConnectedComponents m_connectedComponents;

	std::vector<Edge> m_traversal;
};

