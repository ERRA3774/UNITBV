#include "Node.h"

Node::Node() :
	X(C::UNITIALIZED),
	Y(C::UNITIALIZED),
	VALUE(C::UNITIALIZED),
	SELECTED(false) {
	// DO NOTHING ELSE
}

Node::Node(const unsigned int x, const unsigned int y, const int val, bool selected) :
	X(x),
	Y(y), 
	VALUE(val),
	SELECTED(selected) {
	// DO NOTHING ELSE
}

bool operator==(const Node& lhs, const Node& rhs) {
	return lhs.X == rhs.X && lhs.Y == rhs.Y;
}

bool operator!=(const Node& lhs, const Node& rhs) {
	return lhs.X != rhs.X && lhs.Y != rhs.Y;
}