﻿using LIBGL.Databases;
using LIBGL.Utils;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Data;

namespace LIBGL.ViewModels
{
    public class PublishersPageViewModel : ViewModelBase
    {
        private string _title;
        public string Title
        {
            get
            {
                return _title;
            }
            set
            {
                _title = value;
                OnPropertyChanged(nameof(Title));
            }
        }

        private List<Models.Publisher> _publishers;
        public List<Models.Publisher> Publishers
        {
            get
            {
                return _publishers;
            }
            set
            {
                _publishers = value;
                OnPropertyChanged(nameof(Publishers));
            }
        }

        private readonly ObservableCollection<Models.Publisher> _allPublishers;
        public ObservableCollection<Models.Publisher> AllPublishers
        {
            get => _allPublishers;
            set
            {
                OnPropertyChanged(nameof(AllPublishers));
            }
        }

        public ICollectionView PublishersView { get; private set; }

        public PublishersPageViewModel()
        {
            _title = Consts.PUBLISHERS_PAGE_TITLE;
            _publishers = DbUtils.GetAllActivePublishers();
            _allPublishers = new ObservableCollection<Models.Publisher>(Publishers);
            PublishersView = CollectionViewSource.GetDefaultView(_allPublishers);
        }

        public void FilterPublishers(string inputText)
        {
            inputText = inputText.ToLower();

            PublishersView.Filter = publisher =>
            {
                return ((Models.Publisher)publisher).Name.ToLower().Contains(inputText)
                || ((Models.Publisher)publisher).Address.ToLower().Contains(inputText);
            };
        }
    }
}
