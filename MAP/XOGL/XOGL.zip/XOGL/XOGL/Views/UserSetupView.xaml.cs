﻿using System.Windows;
using System.Windows.Controls;
using XOGL.Utils;
using XOGL.Models;

namespace XOGL.Views
{
    /// <summary>
    /// Interaction logic for UserSetupView.xaml
    /// </summary>
    public partial class UserSetupView : UserControl
    {
        public UserSetupView()
        {
            InitializeComponent();
        }

        private void Button_ClickProfileX(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrEmpty(TbInput.Text))
            {
                MessageBox.Show(XOConstants.UNNAMED_USER_ERROR_MESSAGE);
                return;
            }

            Execute(XOConstants.PLAYER_X);
        }

        private void Button_ClickProfileO(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrEmpty(TbInput.Text))
            {
                MessageBox.Show(XOConstants.UNNAMED_USER_ERROR_MESSAGE);
                return;
            }

            Execute(XOConstants.PLAYER_O);
        }

        private void Execute(int mark)
        {
            User user = new User(TbInput.Text, mark);
            XOGame game = new XOGame(user);
            XOGameView gameView = new XOGameView(game);
            GrdProfile.Children.Clear();
            GrdProfile.Children.Add(gameView);
        }
    }
}
