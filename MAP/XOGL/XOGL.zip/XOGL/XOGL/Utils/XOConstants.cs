﻿namespace XOGL.Utils
{
    public class XOConstants
    {
        // Images
        public static readonly string X_IMG = "..\\Assets\\X.png";
        public static readonly string X_IMG_T = "..\\Assets\\T_X.png";
        public static readonly string O_IMG = "..\\Assets\\O.png";
        public static readonly string O_IMG_T = "..\\Assets\\T_O.png";
        // Images

        // Game
        public static readonly string USER_UNNAMED = "The Unnamed";
        public static readonly string UNNAMED_USER_ERROR_MESSAGE = "Please enter your name!";
        public static readonly int PLAYER_NONE = 0;
        public static readonly int PLAYER_X = 1;
        public static readonly int PLAYER_O = 2;
        public static readonly int GRID_DIMENSION = 3;
        public static readonly int DELAY_SECONDS = 1;
        // Game

        // About
        public static readonly string DEV_LAST_NAME = "Luican";
        public static readonly string DEV_FIRST_NAME = "Gabriel";
        public static readonly string DEV_EMAIL_ADDRESS = "gabriel.luican@student.unitbv.ro";

        public static readonly string SHORT_DESCRIPTION = """
X si O 

Este un joc pentru doi jucători, "X" respectiv "O", 
care marchează pe rând câte o căsuță dintr-un tabel cu 3 linii și 3 coloane. 
Jucătorul care reușește primul să marcheze 3 căsute adiacente pe orizontală, 
verticală sau diagonală caștigă jocul.
""";
        // About
    }
}
