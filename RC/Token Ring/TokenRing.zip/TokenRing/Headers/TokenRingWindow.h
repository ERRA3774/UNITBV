#pragma once

#include <iostream>
#include <vector>
#include <string>
#include <ctime>
#include <queue>
#include <fstream>

#include <raylib.h>

#include "../Utils/Constants.h"
#include "../Headers/TokenRing.h"

class TokenRingWindow
{
public:
	TokenRingWindow();

	void OnCreate();
};

