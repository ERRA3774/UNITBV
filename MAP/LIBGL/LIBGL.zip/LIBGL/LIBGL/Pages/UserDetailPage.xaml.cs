﻿using LIBGL.Databases;
using LIBGL.Utils;
using LIBGL.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace LIBGL.Pages
{
    /// <summary>
    /// Interaction logic for UserDetailPage.xaml
    /// </summary>
    public partial class UserDetailPage : Page
    {
        private readonly Models.User _user;
        public UserDetailsViewModel UserDetailsViewModel { get; }

        public UserDetailPage(UserDetailsViewModel userDetailsViewModel)
        {
            InitializeComponent();
            UserDetailsViewModel = userDetailsViewModel;
            DataContext = UserDetailsViewModel;

            _user = UserDetailsViewModel.User;

            if (_user.UserId.Equals(int.MinValue))
            {
                ButtonDelete.Visibility = Visibility.Hidden;
                ButtonSave.Content = Consts.ADD_TEXT;
                UserDetailsHeader.Text = Consts.USER_ADD_TEXT;
            }
        }

        private void ButtonSave_Click(object sender, RoutedEventArgs e)
        {
            if (sender is not Button button)
            {
                return;
            }

            Models.User user = new Models.User
            {
                FirstName = TextBoxFirstName.Text,
                LastName = TextBoxLastName.Text,
                Email = TextBoxEmail.Text,
                Phone = TextBoxPhone.Text
            };

            if (_user.UserId.Equals(int.MinValue))
            {
                DbUtils.InsertUser(user);
            }
            else
            {
                user.UserId = _user.UserId;
                user.Active = _user.Active;
                DbUtils.UpdateUser(user);
            }

            NavigationService.Navigate(new UsersPage());
        }

        private void ButtonCancel_Click(object sender, RoutedEventArgs e)
        {
            if (sender is not Button)
            {
                return;
            }

            NavigationService.Navigate(new UsersPage());
        }

        private void ButtonDelete_Click(object sender, RoutedEventArgs e)
        {
            if (sender is not Button button)
            {
                return;
            }

            DbUtils.DeleteUser(_user.UserId);

            NavigationService.Navigate(new UsersPage());
        }

        private void PrimaryInputLimit_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            if (sender is not TextBox textBox)
            {
                return;
            }

            if (textBox.Text.Length >= Consts.TEXTBOX_PRIMARY_LIMIT)
            {
                e.Handled = true;
            }
        }

        private void SecondaryInputLimit_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            if (sender is not TextBox textBox)
            {
                return;
            }

            if (textBox.Text.Length >= Consts.TEXTBOX_SECONDARY_LIMIT)
            {
                e.Handled = true;
            }
        }
    }
}
