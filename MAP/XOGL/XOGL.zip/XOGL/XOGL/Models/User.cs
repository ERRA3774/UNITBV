﻿using XOGL.Utils;

namespace XOGL.Models
{
    public class User
    {
        private string _name; 
        public string Name
        {
            get => _name; 
            set => _name = value;
        }

        private int _mark;
        public int Mark
        {
            get => _mark;
            set => _mark = value;
        }

        public User()
        {
            _name = XOConstants.USER_UNNAMED;
            _mark = XOConstants.PLAYER_NONE;
        }

        public User(string name, int mark)
        {
            _name = name;
            _mark = mark;
        }
    }
}
