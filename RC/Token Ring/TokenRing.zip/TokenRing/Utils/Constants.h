#pragma once

#include <cmath>
#include <raylib.h>

extern const int SCREEN_WIDTH;
extern const int SCREEN_HEIGHT;

extern const float NET_RECT_X;
extern const float NET_RECT_Y;
extern const float NET_RECT_WIDTH;
extern const float NET_RECT_HEIGHT;

extern const float EARTH_X;
extern const float EARTH_Y;

extern const float EARTH_RADIUS;
extern const float MOON_RADIUS;
extern const float MOON_DISTANCE;

extern const float STEP_UNIT;

extern const int STARS_COUNT;

extern const float SAT_A_X;
extern const float SAT_A_Y;
extern const float SAT_B_X;
extern const float SAT_B_Y;
extern const float SAT_C_X;
extern const float SAT_C_Y;
extern const float SAT_D_X;
extern const float SAT_D_Y;
extern const float SAT_E_X;
extern const float SAT_E_Y;
extern const float SAT_F_X;
extern const float SAT_F_Y;
extern const char* EARTH_IMG;
extern const char* MOON_IMG;

extern const char* SAT_A_IMG;
extern const char* SAT_B_IMG;
extern const char* SAT_C_IMG;
extern const char* SAT_D_IMG;
extern const char* SAT_E_IMG;
extern const char* SAT_F_IMG;

extern const char* SAT_A_MSG;
extern const char* SAT_B_MSG;
extern const char* SAT_C_MSG;
extern const char* SAT_D_MSG;
extern const char* SAT_E_MSG;
extern const char* SAT_F_MSG;

extern const float GUI_RECT_X;
extern const float GUI_RECT_Y;
extern const float GUI_RECT_WIDTH;
extern const float GUI_RECT_HEIGHT;

extern const char* SENDING_STATE_TEXT;
extern const char* SEARCHING_STATE_TEXT;
extern const char* RETURNING_STATE_TEXT;

extern const char* SENDER_LABEL_TEXT;
extern const char* DESTINATION_LABEL_TEXT;

extern const char* COMP_A_LABEL_TEXT;
extern const char* COMP_B_LABEL_TEXT;
extern const char* COMP_C_LABEL_TEXT;
extern const char* COMP_D_LABEL_TEXT;
extern const char* COMP_E_LABEL_TEXT;
extern const char* COMP_F_LABEL_TEXT;

extern const int PRIMARY_FONT_SIZE;
extern const int SECONDARY_FONT_SIZE;
extern const int TERTIARY_FONT_SIZE;
extern const int QUARTERNARY_FONT_SIZE;
extern const char* LOG_TEXT;

extern const Color SPACE_VOID;

extern const Color PRIMARY_BLUE;
extern const Color SECONDARY_BLUE;
extern const Color PRIMARY_BROWN;
extern const Color SECONDARY_BROWN;

extern const Color GUI_BACKGROUND;
extern const Color BLOOD_MOON;
extern const Color SILVER_MOON;
extern const Color BLUE_MOON;

