﻿using LIBGL.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace LIBGL.Pages
{
    /// <summary>
    /// Interaction logic for DashboardPage.xaml
    /// </summary>
    public partial class DashboardPage : Page
    {
        public DashboardPage()
        {
            InitializeComponent();
            DataContext = new DashboardPageViewModel();
        }

        private void DataGridDashboard_AutoGeneratingColumn(object sender, DataGridAutoGeneratingColumnEventArgs e)
        {
            if (e.PropertyName == "AuthorId" || e.PropertyName == "BookId" || e.PropertyName == "PublisherId" || e.PropertyName == "UserId" || e.PropertyName == "BookTypeId")
            {
                e.Column.Header = "_id";
                e.Column.Width = 30;
            }

            if (e.PropertyName == "PublishYear")
            {
                e.Column.Width = 90;
            }

            if (e.PropertyName == "Stock")
            {
                e.Column.Width = 50;
            }

            if (e.PropertyName == "Active")
            {
                e.Column.Width = 50;
            }
        }
    }
}
