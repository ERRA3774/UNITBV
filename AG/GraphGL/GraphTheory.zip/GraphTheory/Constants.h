#pragma once
#include <string>
#include <vector>

class Constants {
public:
	static const std::string FONT_PATH;
	static const std::string WINDOW_TITLE;

	static const unsigned int WINDOW_WIDTH;
	static const unsigned int WINDOW_HEIGHT;

	static const int LEFT_BOUND;
	static const int UPPER_BOUND;
	static const int LOWER_BOUND;
	static const int RIGHT_BOUND;

	static const float NODE_RADIUS;
	static const float NODE_SPACE;
	static const float PI;
	static const float DEG_180;
	static const float LINE_THICKNESS;
	static const float UNITIALIZED_WEIGHT;

	static const int UNITIALIZED;

	static const std::vector<std::string> MODE_NAMES;
	static const std::vector<std::string> TRAVERSAL_NAMES;
};
