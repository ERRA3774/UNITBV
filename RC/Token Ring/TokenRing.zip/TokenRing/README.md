# Token Ring visualization

![alt text](image-2.png)

## Quick Start: Windows

https://github.com/microsoft/vcpkg

Prerequisites:

* Windows 7 or newer
* Git
* Visual Studio 2015 Update 3 or greater with the English language pack

First, download and bootstrap vcpkg itself; it can be installed anywhere, but generally we recommend using vcpkg as a submodule so the consuming repo can stay self-contained. Alternatively, vcpkg can be installed globally; we recommend somewhere like C:\src\vcpkg or C:\dev\vcpkg, since otherwise you may run into path issues for some port build systems.


```cmd
> git clone https://github.com/microsoft/vcpkg
> .\vcpkg\bootstrap-vcpkg.bat
```

To install [raylib](https://www.raylib.com/index.html) for your project, run:

```cmd
> .\vcpkg\vcpkg install raylib
```

In order to use vcpkg with Visual Studio,
run the following command (may require administrator elevation):

```cmd
> .\vcpkg\vcpkg integrate install
```

