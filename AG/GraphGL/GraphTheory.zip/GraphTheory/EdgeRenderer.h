#pragma once

#include <SFML/Graphics.hpp>
#include <iostream>
#include "Graph.h"
#include <algorithm>
#include <cmath>

#include "Constants.h"

class EdgeRenderer {
	using C = Constants;

public:
	EdgeRenderer(Graph& graph);

	void Render(sf::RenderWindow& window, const Edge& edge, sf::Color lineColor = sf::Color::White);

private:
	Graph& m_graph;

	sf::RectangleShape m_line;
	sf::CircleShape m_arrowhead;
	sf::Font m_font;
	sf::Text m_weight;
};

