#pragma once
#include <SFML/Graphics.hpp>
#include <iostream>

#include "Constants.h"
#include "Graph.h"

class NodeRenderer {
	using C = Constants;

public:
	NodeRenderer(Graph& graph);

	void Render(sf::RenderWindow& window, const Node& node);

private:
	void _InitNode();
	void _InitText();

private:
	Graph& m_graph;

	sf::CircleShape m_nodeShape;
	sf::Vector2i m_nodePosition;
	sf::Text m_nodeText;
	sf::Font m_font;
};
