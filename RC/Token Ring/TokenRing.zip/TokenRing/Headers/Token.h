#pragma once

#include <string>

class Token {
public:
	std::string Sender;
	std::string Destination;
	std::string Message;

	Token();
	Token(std::string sender, std::string destination, std::string message);
};

