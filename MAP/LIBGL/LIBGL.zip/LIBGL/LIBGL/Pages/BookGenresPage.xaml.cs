﻿using LIBGL.Databases;
using LIBGL.Utils;
using LIBGL.ViewModels;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace LIBGL.Pages
{
    /// <summary>
    /// Interaction logic for BookGenresPage.xaml
    /// </summary>
    public partial class BookGenresPage : Page
    {
        private readonly BookGenresPageViewModel _viewModel;
        public BookGenresPage()
        {
            InitializeComponent();
            _viewModel = new BookGenresPageViewModel();
            DataContext = _viewModel;
        }

        private void DataGridBookGenres_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            if (sender is not DataGrid grid || grid.SelectedItem is not Models.BookType || grid.SelectedItems.Count != 1)
            {
                return;
            }

            Models.BookType? selectedBookGenre = grid.SelectedItem as Models.BookType;
            DataGridBookGenres.UnselectAll();
            NavigationService.Navigate(ChildPage(selectedBookGenre));
        }

        private void ButtonPlus_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(ChildPage(new Models.BookType()));
        }

        private BookGenreDetailPage ChildPage(Models.BookType? bookGenre)
        {
            bookGenre ??= new Models.BookType();

            BookGenreDetailsViewModel childViewModel = new BookGenreDetailsViewModel(_viewModel, bookGenre);
            BookGenreDetailPage? childPage = new BookGenreDetailPage(childViewModel);
            return childPage;
        }

        private void FilterBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (sender is not TextBox filterBox)
            {
                return;
            }

            _viewModel.FilterBookGenres(filterBox.Text);
        }

        private void DataGridBookGenres_AutoGeneratingColumn(object sender, DataGridAutoGeneratingColumnEventArgs e)
        {
            if (e.PropertyName == "BookTypeId")
            {
                e.Cancel = true;
            }

            if (e.PropertyName == "Active")
            {
                e.Cancel = true;
            }
        }
    }
}
