﻿using LIBGL.Databases;
using LIBGL.Utils;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Data;

namespace LIBGL.ViewModels
{
    public class BooksPageViewModel : ViewModelBase
    {
        private string _title;
        public string Title
        {
            get
            {
                return _title;
            }
            set
            {
                _title = value;
                OnPropertyChanged(nameof(Title));
            }
        }

        private List<Models.Book> _books;
        public List<Models.Book> Books
        {
            get
            {
                return _books;
            }
            set
            {
                _books = value;
                OnPropertyChanged(nameof(Books));
            }
        }

        private readonly ObservableCollection<Models.Book> _allBooks;
        public ObservableCollection<Models.Book> AllBooks
        {
            get => _allBooks;
            set
            {
                OnPropertyChanged(nameof(AllBooks));
            }
        }

        public ICollectionView BooksView { get; private set; }

        public BooksPageViewModel()
        {
            _title = Consts.BOOKS_PAGE_TITLE;
            _books = DbUtils.GetAllActiveBooks();
            _allBooks = new ObservableCollection<Models.Book>(Books);
            BooksView = CollectionViewSource.GetDefaultView(_allBooks);
        }

        public void FilterBooks(string inputText)
        {
            inputText = inputText.ToLower();

            BooksView.Filter = book =>
            {
                return ((Models.Book)book).Title.ToLower().Contains(inputText)
                || ((Models.Book)book).PublishYear.ToString().ToLower().Contains(inputText)
                || ((Models.Book)book).Stock.ToString().ToLower().Contains(inputText);
            };
        }
    }
}
