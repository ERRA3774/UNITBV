﻿using LIBGL.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace LIBGL.Pages
{
    /// <summary>
    /// Interaction logic for PublishersPage.xaml
    /// </summary>
    public partial class PublishersPage : Page
    {
        private readonly PublishersPageViewModel _viewModel;
        public PublishersPage()
        {
            InitializeComponent();
            _viewModel = new PublishersPageViewModel();
            DataContext = _viewModel;
        }

        private void DataGridPublishers_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            if (sender is not DataGrid grid || grid.SelectedItem is not Models.Publisher || grid.SelectedItems.Count != 1)
            {
                return;
            }

            Models.Publisher? selectedPublisher = grid.SelectedItem as Models.Publisher;
            DataGridPublishers.UnselectAll();
            NavigationService.Navigate(ChildPage(selectedPublisher));
        }

        private void ButtonPlus_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(ChildPage(new Models.Publisher()));
        }

        private PublisherDetailPage ChildPage(Models.Publisher? publisher)
        {
            publisher ??= new Models.Publisher();

            PublisherDetailsViewModel childViewModel = new PublisherDetailsViewModel(_viewModel, publisher);
            PublisherDetailPage? childPage = new PublisherDetailPage(childViewModel);
            return childPage;
        }

        private void FilterBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (sender is not TextBox filterBox)
            {
                return;
            }

            _viewModel.FilterPublishers(filterBox.Text);
        }

        private void DataGridPublishers_AutoGeneratingColumn(object sender, DataGridAutoGeneratingColumnEventArgs e)
        {
            if (e.PropertyName == "PublisherId")
            {
                e.Cancel = true;
            }

            if (e.PropertyName == "Active")
            {
                e.Cancel = true;
            }
        }
    }
}
