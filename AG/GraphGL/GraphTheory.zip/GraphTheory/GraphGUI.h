#pragma once
#include <SFML/Graphics.hpp>
#include <iostream>
#include <string>
#include "Constants.h"

class GraphGUI {
	using C = Constants;
public:
	GraphGUI();

	void Render(sf::RenderWindow& window, const int mode, const int traversal, const float edgeWeight);

private:
	sf::RectangleShape m_box;

	sf::Font m_textFont;
	sf::Text m_modeName;
	sf::Text m_traversalName;
	sf::Text m_edgeWeight;
	sf::Text m_commands;
};

