// Cheetsheet
// https://www.raylib.com/cheatsheet/cheatsheet.html
//--------------------------------------------------------------------------------------

#include "Headers/TokenRingWindow.h"

int main(void) {

	TokenRingWindow window;

	window.OnCreate();

	return 0;
}