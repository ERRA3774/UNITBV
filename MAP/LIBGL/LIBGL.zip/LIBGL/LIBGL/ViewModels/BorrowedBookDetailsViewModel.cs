﻿using LIBGL.Databases;
using LIBGL.Models;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LIBGL.ViewModels
{
    public class BorrowedBookDetailsViewModel : ViewModelBase
    {
        private readonly BorrowedBooksPageViewModel _parent;

        private Models.UserBook _userBook;
        public Models.UserBook UserBook
        {
            get
            {
                return _userBook;
            }
            set
            {
                _userBook = value;
                OnPropertyChanged(nameof(UserBook));
            }
        }

        private bool _canClickSaveButton;
        public bool CanClickSaveButton
        {
            get { return _canClickSaveButton; }
            set
            {
                _canClickSaveButton = value;
                OnPropertyChanged(nameof(CanClickSaveButton));
            }
        }

        public BorrowedBookDetailsViewModel(BorrowedBooksPageViewModel parent, Models.UserBook userBook)
        {
            _userBook = userBook;
            _parent = parent;

            _canClickSaveButton = false;
        }

        private void UpdateCanClickSaveButton()
        {
            CanClickSaveButton = false;
        }
    }
}
