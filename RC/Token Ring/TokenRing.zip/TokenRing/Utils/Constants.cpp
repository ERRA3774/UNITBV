#include "Constants.h"

const int SCREEN_WIDTH = 1600;
const int SCREEN_HEIGHT = 900;

const float NET_RECT_X = 30;
const float NET_RECT_Y = 30;
const float NET_RECT_WIDTH = SCREEN_WIDTH * 0.66;
const float NET_RECT_HEIGHT = SCREEN_HEIGHT - 60;

const float GUI_RECT_X = NET_RECT_WIDTH + 60;
const float GUI_RECT_Y = 30;
const float GUI_RECT_WIDTH = SCREEN_WIDTH * 0.33 - 90;
const float GUI_RECT_HEIGHT = SCREEN_HEIGHT - 60;

const float EARTH_X = NET_RECT_WIDTH / 2;
const float EARTH_Y = NET_RECT_HEIGHT / 2;

const float EARTH_RADIUS = 100.0f;
const float MOON_RADIUS = 30.0f;
const float MOON_DISTANCE = 300.0f;

const float STEP_UNIT = 1.5f;
const int STARS_COUNT = 300;

const float SAT_A_X = EARTH_X + MOON_DISTANCE * cosf(1.0f);
const float SAT_A_Y = EARTH_Y + MOON_DISTANCE * sinf(1.0f);

const float SAT_B_X = EARTH_X + MOON_DISTANCE * cosf(2.0f);
const float SAT_B_Y = EARTH_Y + MOON_DISTANCE * sinf(2.0f);

const float SAT_C_X = EARTH_X + MOON_DISTANCE * cosf(3.0f);
const float SAT_C_Y = EARTH_Y + MOON_DISTANCE * sinf(3.0f);

const float SAT_D_X = EARTH_X + MOON_DISTANCE * cosf(4.0f);
const float SAT_D_Y = EARTH_Y + MOON_DISTANCE * sinf(4.0f);

const float SAT_E_X = EARTH_X + MOON_DISTANCE * cosf(5.0f);
const float SAT_E_Y = EARTH_Y + MOON_DISTANCE * sinf(5.0f);

const float SAT_F_X = EARTH_X + MOON_DISTANCE * cosf(6.0f);
const float SAT_F_Y = EARTH_Y + MOON_DISTANCE * sinf(6.0f);

const char* EARTH_IMG = "Resources/earth.png";
const char* MOON_IMG = "Resources/moon.png";

const char* SAT_A_IMG = "Resources/sat1.png";
const char* SAT_B_IMG = "Resources/sat2.png";
const char* SAT_C_IMG = "Resources/sat3.png";
const char* SAT_D_IMG = "Resources/sat4.png";
const char* SAT_E_IMG = "Resources/sat5.png";
const char* SAT_F_IMG = "Resources/sat6.png";

const char* SAT_A_MSG = "Resources/secretsA.txt";
const char* SAT_B_MSG = "Resources/secretsB.txt";
const char* SAT_C_MSG = "Resources/secretsC.txt";
const char* SAT_D_MSG = "Resources/secretsD.txt";
const char* SAT_E_MSG = "Resources/secretsE.txt";
const char* SAT_F_MSG = "Resources/secretsF.txt";

const char* SENDING_STATE_TEXT = "Sending . . .";
const char* SEARCHING_STATE_TEXT = "Searching . . .";
const char* RETURNING_STATE_TEXT = "Returning . . .";

const char* SENDER_LABEL_TEXT = "Sender";
const char* DESTINATION_LABEL_TEXT = "Destination";

const char* COMP_A_LABEL_TEXT = "Satellite A ip:";
const char* COMP_B_LABEL_TEXT = "Satellite B ip:";
const char* COMP_C_LABEL_TEXT = "Satellite C ip:";
const char* COMP_D_LABEL_TEXT = "Satellite D ip:";
const char* COMP_E_LABEL_TEXT = "Satellite E ip:";
const char* COMP_F_LABEL_TEXT = "Satellite F ip:";

const int PRIMARY_FONT_SIZE = 50;
const int SECONDARY_FONT_SIZE = 40;
const int TERTIARY_FONT_SIZE = 30;
const int QUARTERNARY_FONT_SIZE = 20;
const char* LOG_TEXT = "Logs";

const Color SPACE_VOID = { 12, 12, 12, 255 };

const Color PRIMARY_BLUE = {21, 52, 72, 255};
const Color SECONDARY_BLUE = { 50, 111, 121, 255 };
const Color PRIMARY_BROWN = { 148, 137, 121, 255 };
const Color SECONDARY_BROWN = {223, 208, 184, 255};

const Color BLOOD_MOON = {196, 12, 12, 255};
const Color SILVER_MOON = {204, 204, 204, 255};
const Color BLUE_MOON = {7, 102, 173, 255};