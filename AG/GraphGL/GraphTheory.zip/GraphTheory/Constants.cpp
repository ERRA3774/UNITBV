#include "Constants.h"

const std::string Constants::WINDOW_TITLE = "Graph Theory";
const std::string Constants::FONT_PATH = "RobotoMono.ttf";

const unsigned int Constants::WINDOW_WIDTH = 1920;
const unsigned int Constants::WINDOW_HEIGHT = 1080;

const int Constants::UPPER_BOUND = 40;
const int Constants::LOWER_BOUND = 1030;
const int Constants::LEFT_BOUND = 40;
const int Constants::RIGHT_BOUND = 1450;

const float Constants::NODE_RADIUS = 32.0f;
const float Constants::NODE_SPACE = 150.0f;
const float Constants::PI = 3.1415926f;
const float Constants::DEG_180 = 180.0f;
const float Constants::LINE_THICKNESS = 3.2f;
const float Constants::UNITIALIZED_WEIGHT = 1.0f;

const int Constants::UNITIALIZED = INT_MAX;

const std::vector<std::string> Constants::MODE_NAMES = { 
	"Default", 
	"Create", 
	"Move", 
	"Connect",  
	"Traverse",
};

const std::vector<std::string> Constants::TRAVERSAL_NAMES = {
	"None",
	"ShortPath",
	"Prim",
	"Kruskal",
	"Dijkstra",
	"BellmanFord",
	"FloydWarshall",
};