﻿using System.Windows;
using System.Windows.Threading;
using XOGL.Utils;

namespace XOGL.Models
{
    public class XOGame
    {
        private Board _board;
        public Board Board => _board;

        private User _user;
        public User User => _user;

        private int _computerPlayer;
        public int ComputerPlayer => _computerPlayer;

        private int _playerOnTurn;
        public int PlayerOnTurn => _playerOnTurn;

        private State _gameState;
        public State GameState => _gameState;

        public XOGame(User user)
        {
            _board = new Board();
            _user = user;
            _computerPlayer = _user.Mark == XOConstants.PLAYER_X ? XOConstants.PLAYER_O : XOConstants.PLAYER_X;
            _gameState = _user.Mark == XOConstants.PLAYER_X ? State.UserToMove : State.ComputerToMove;
            _playerOnTurn = XOConstants.PLAYER_X;
        }

        public void UserMove(int row, int col)
        {
            _board.MakeMove(row, col, _user.Mark);
            PassTurn();
        }

        public Board.Cell ComputerMove()
        {
            Random random = new Random();
            Board.Cell randomSpot = _board.RemainingSpots[random.Next(_board.RemainingSpots.Count)];
            _board.MakeMove(randomSpot.Row, randomSpot.Col, _computerPlayer);
            PassTurn();
            return randomSpot;
        }

        private void PassTurn()
        {
            _playerOnTurn = _playerOnTurn == XOConstants.PLAYER_X ? XOConstants.PLAYER_O : XOConstants.PLAYER_X;
        }

        public enum State
        {
            UserToMove,
            ComputerToMove,
            Won,
            Lost,
            Draw
        }

        public State SetState()
        {
            if (_board.GameWonBy(_user.Mark))
            {
                return State.Won;
            }
            else if (_board.GameWonBy(_computerPlayer))
            {
                return State.Lost;
            }
            else if (_board.GameDraw())
            {
                return State.Draw;
            }
            else if (_playerOnTurn == _computerPlayer)
            {
                return State.ComputerToMove;
            }
            else
            {
                return State.UserToMove;
            }
        }
    }
}
