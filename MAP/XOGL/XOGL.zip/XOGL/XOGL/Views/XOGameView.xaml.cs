﻿using System.Windows;
using System.Windows.Controls;
using System.Windows.Media.Imaging;

using XOGL.Utils;
using XOGL.Models;
using System.Windows.Threading;

namespace XOGL.Views
{
    public partial class XOGameView : UserControl
    {
        private XOGame _game;
        private string _userMark;
        private string _userHover;
        private string _computerMark;
        private string _computerHover;
        private List<Button> _enabledButtons;

        public XOGameView(XOGame game)
        {
            InitializeComponent();
            StartGame(game.User);
        }

        private void StartGame(User user)
        {
            _game = new XOGame(user);
            _userMark = user.Mark == XOConstants.PLAYER_X ? XOConstants.X_IMG : XOConstants.O_IMG;
            _userHover = user.Mark == XOConstants.PLAYER_X ? XOConstants.X_IMG_T : XOConstants.O_IMG_T;
            _computerMark = user.Mark == XOConstants.PLAYER_X ? XOConstants.O_IMG : XOConstants.X_IMG;
            _computerHover = user.Mark == XOConstants.PLAYER_X ? XOConstants.O_IMG_T : XOConstants.X_IMG_T;
            _enabledButtons = new List<Button>(9);

            foreach (Button button in GrdBoard.Children)
            {
                button.IsEnabled = true;
                button.Content = null;
                _enabledButtons.Add(button);
            }

            OnStateChanged(_game.SetState());
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            Button button = sender as Button;
            int row = Grid.GetRow(button);
            int col = Grid.GetColumn(button);

            if (button != null)
            {
                _game.UserMove(row, col);

                button.Content = new Image
                {
                    Source = new BitmapImage(new Uri(_userMark, UriKind.Relative)),
                };
                button.IsEnabled = false;
                _enabledButtons.Remove(button);
            }   

            OnStateChanged(_game.SetState());
        }

        private void OnComputerMove()
        {
            Board.Cell cellPicked = _game.ComputerMove();
            Button buttonPicked = FindButtonOnGrid(cellPicked.Row, cellPicked.Col);

            SimulateComputerHover(buttonPicked);

            buttonPicked.IsEnabled = false;
            _enabledButtons.Remove(buttonPicked);

            OnStateChanged(_game.SetState());
        }

        private void SimulateComputerHover(Button buttonPicked)
        {
            var hoverTimer = new DispatcherTimer { Interval = TimeSpan.FromMilliseconds(200) };

            foreach (Button button in _enabledButtons)
            {
                hoverTimer.Start();

                button.Content = new Image { Source = new BitmapImage(new Uri(_computerHover, UriKind.Relative)) };

                hoverTimer.Tick += (sender, args) =>
                {
                    hoverTimer.Stop();

                    button.Content = null;
                };
            }

            var playTimer = new DispatcherTimer { Interval = TimeSpan.FromSeconds(XOConstants.DELAY_SECONDS) };
            playTimer.Start();
            playTimer.Tick += (sender, args) =>
            {
                playTimer.Stop();
                buttonPicked.Content = new Image
                {
                    Source = new BitmapImage(new Uri(_computerMark, UriKind.Relative)),
                };
            };
        }

        private Button FindButtonOnGrid(int row, int col)
        {
            foreach (Button button in _enabledButtons)
            {
                if (Grid.GetRow(button) == row && Grid.GetColumn(button) == col)
                {
                    return button;
                }
            }

            return null;
        }

        private void Button_MouseEnter(object sender, RoutedEventArgs e)
        {
            Button button = sender as Button;

            if (button != null && button.IsEnabled == true)
            {
                button.Content = new Image
                {
                    Source = new BitmapImage(new Uri(_userHover, UriKind.Relative))
                };
            }
        }

        private void Button_MouseLeave(object sender, RoutedEventArgs e)
        {
            Button button = sender as Button;

            if (button != null && button.IsEnabled == true)
            {
                button.Content = null;
            }
        }

        private void OnStateChanged(XOGame.State state)
        {
            switch (state)
            {
                case XOGame.State.Won:
                    MessageBox.Show($"{_game.User.Name} ai castigat!");
                    StartGame(_game.User);
                    break;

                case XOGame.State.Lost:
                    MessageBox.Show($"{_game.User.Name} ai pierdut!");
                    StartGame(_game.User);
                    break;

                case XOGame.State.Draw:
                    MessageBox.Show($"Egalitate!");
                    StartGame(_game.User);
                    break;

                case XOGame.State.ComputerToMove:
                    OnComputerMove();
                    break;
            }
        }
    }
}
