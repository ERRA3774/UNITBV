﻿using LIBGL.Databases;
using LIBGL.Utils;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Data;

namespace LIBGL.ViewModels
{
    public class BookGenresPageViewModel : ViewModelBase
    {
        private string _title;
        public string Title
        {
            get
            {
                return _title;
            }
            set
            {
                _title = value;
                OnPropertyChanged(nameof(Title));
            }
        }

        private List<Models.BookType> _bookGenres;
        public List<Models.BookType> BookGenres
        {
            get
            {
                return _bookGenres;
            }
            set
            {
                _bookGenres = value;
                OnPropertyChanged(nameof(BookGenres));
            }
        }

        private readonly ObservableCollection<Models.BookType> _allBookGenres;
        public ObservableCollection<Models.BookType> AllBookGenres
        {
            get => _allBookGenres;
            set
            {
                OnPropertyChanged(nameof(AllBookGenres));
            }
        }

        public ICollectionView BookGenresView { get; private set; }

        public BookGenresPageViewModel()
        {
            _title = Consts.GENRES_PAGE_TITLE;
            _bookGenres = DbUtils.GetAllActiveBookGenres();
            _allBookGenres = new ObservableCollection<Models.BookType>(BookGenres);
            BookGenresView = CollectionViewSource.GetDefaultView(_allBookGenres);
        }

        public void FilterBookGenres(string inputText)
        {
            inputText = inputText.ToLower();

            BookGenresView.Filter = bookGenre =>
            {
                return ((Models.BookType)bookGenre).Name.ToLower().Contains(inputText);
            };
        }
    }
}
