﻿using LIBGL.Commands;
using Microsoft.IdentityModel.Tokens;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;

namespace LIBGL.ViewModels
{
    public class AuthorDetailsViewModel : ViewModelBase
    {
        private readonly AuthorsPageViewModel _parent;

        private Models.Author _author;
        public Models.Author Author
        {
            get
            {
                return _author;
            }
            set
            {
                _author = value;
                OnPropertyChanged(nameof(Author));
            }
        }

        private string _firstNameBoxText;
        public string FirstNameBoxText
        {
            get
            {
                return _firstNameBoxText;
            }
            set
            {
                _firstNameBoxText = value;
                OnPropertyChanged(nameof(FirstNameBoxText));
                UpdateCanClickSaveButton();
            }
        }

        private string _lastNameBoxText;
        public string LastNameBoxText
        {
            get
            {
                return _lastNameBoxText;
            }
            set
            {
                _lastNameBoxText = value;
                OnPropertyChanged(nameof(LastNameBoxText));
                UpdateCanClickSaveButton();
            }
        }

        private DateTime? _selectedDate;
        public DateTime? SelectedDate
        {
            get
            {
                return _selectedDate;
            }
            set
            {
                _selectedDate = value;
                OnPropertyChanged(nameof(SelectedDate));
                UpdateCanClickSaveButton();
            }
        }

        private bool _canClickSaveButton;
        public bool CanClickSaveButton
        {
            get { return _canClickSaveButton; }
            set
            {
                _canClickSaveButton = value;
                OnPropertyChanged(nameof(CanClickSaveButton));
            }
        }

        private void UpdateCanClickSaveButton()
        {
            CanClickSaveButton = !string.IsNullOrEmpty(FirstNameBoxText) 
                && !string.IsNullOrEmpty(LastNameBoxText) 
                && SelectedDate.HasValue;
        }

        public AuthorDetailsViewModel(AuthorsPageViewModel parent, Models.Author author)
        {
            _author = author;
            _parent = parent;
            _firstNameBoxText = author.FirstName;
            _lastNameBoxText = author.LastName;
            _selectedDate = author.BirthDate == new DateOnly() ? null : author.BirthDate.ToDateTime(TimeOnly.MinValue);
            _canClickSaveButton = !string.IsNullOrEmpty(author.FirstName) && !string.IsNullOrEmpty(author.LastName) && SelectedDate.HasValue;
        }
    }
}
