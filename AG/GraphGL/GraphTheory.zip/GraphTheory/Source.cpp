#include "GraphApp.h"

int main() {
	Graph gr;
	GraphApp app(gr);
	app.Run();

	return EXIT_SUCCESS;
}