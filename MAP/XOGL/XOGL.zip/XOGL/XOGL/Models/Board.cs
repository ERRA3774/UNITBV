﻿using XOGL.Utils;

namespace XOGL.Models
{
    public class Board
    {
        private int[,] _grid;
        private int _dimension;

        public struct Cell
        {
            public int Row;
            public int Col;

            public Cell(int row, int col)
            {
                Row = row;
                Col = col;
            }
        }

        private List<Cell> _remainingSpots;
        public List<Cell> RemainingSpots => _remainingSpots;
        public Board()
        {
            _dimension = XOConstants.GRID_DIMENSION;
            _grid = new int[XOConstants.GRID_DIMENSION, XOConstants.GRID_DIMENSION];
            _remainingSpots = new List<Cell>();
            Initialize();
        }

        private void Initialize()
        {
            for (int row = 0; row < _dimension; row++)
            {
                for (int col = 0; col < _dimension; col++)
                {
                    _grid[row, col] = XOConstants.PLAYER_NONE;
                    _remainingSpots.Add(new Cell(row, col));
                }
            }
        }

        public bool MakeMove(int row, int col, int player)
        {
            if (_grid[row, col] == 0)
            {
                _grid[row, col] = player;
                Cell spot = _remainingSpots.Find(spot => spot.Row == row && spot.Col == col);
                _remainingSpots.Remove(spot);
                return true;
            }

            return false;
        }

        public bool GameWonBy(int player)
        {
            if (MatchOnMainDiagonal(player))
            {
                return true;
            }

            if (MatchOnSecondaryDiagonal(player))
            {
                return true;
            }

            if (MatchOnAnyRowOrColumn(player))
            {
                return true;
            }

            return false;
        }

        public bool GameDraw()
        {
            for (int row = 0; row < _dimension; row++)
            {
                for (int col = 0; col < _dimension; col++)
                {
                    if (_grid[row, col] == XOConstants.PLAYER_NONE)
                    {
                        return false;
                    }

                }
            }

            return true;
        }

        private bool MatchOnMainDiagonal(int player)
        {
            return _grid[0, 0] == player && _grid[1, 1] == player && _grid[2, 2] == player;
        }

        private bool MatchOnSecondaryDiagonal(int player)
        {
            return _grid[0, 2] == player && _grid[1, 1] == player && _grid[2, 0] == player;
        }

        private bool MatchOnAnyRowOrColumn(int player)
        {
            for (int i = 0; i < _dimension; i++)
            {
                if (_grid[i, 0] == player && _grid[i, 1] == player && _grid[i, 2] == player)
                {
                    return true;
                }

                if (_grid[0, i] == player && _grid[1, i] == player && _grid[2, i] == player)
                {
                    return true;
                }
            }

            return false;
        }
    }
}
