﻿using LIBGL.Databases;
using LIBGL.Utils;
using LIBGL.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace LIBGL.Pages
{
    /// <summary>
    /// Interaction logic for PublisherDetailPage.xaml
    /// </summary>
    public partial class PublisherDetailPage : Page
    {
        private readonly Models.Publisher _publisher;
        public PublisherDetailsViewModel PublisherDetailsViewModel { get; }

        public PublisherDetailPage(PublisherDetailsViewModel publisherDetailsViewModel)
        {
            InitializeComponent();
            PublisherDetailsViewModel = publisherDetailsViewModel;
            DataContext = PublisherDetailsViewModel;

            _publisher = publisherDetailsViewModel.Publisher;

            if (_publisher.PublisherId.Equals(int.MinValue))
            {
                ButtonDelete.Visibility = Visibility.Hidden;
                ButtonSave.Content = Consts.ADD_TEXT;
                PublisherDetailsHeader.Text = Consts.PUBLISHER_ADD_TEXT;
            }
        }

        private void ButtonSave_Click(object sender, RoutedEventArgs e)
        {
            if (sender is not Button button)
            {
                return;
            }

            Models.Publisher publisher = new Models.Publisher
            {
                Name = TextBoxPublisherName.Text,
                Address = TextBoxAddress.Text,
            };

            if (_publisher.PublisherId.Equals(int.MinValue))
            {
                DbUtils.InsertPublisher(publisher);
            }
            else
            {
                publisher.PublisherId = _publisher.PublisherId;
                publisher.Active = _publisher.Active;
                DbUtils.UpdatePublisher(publisher);
            }

            NavigationService.Navigate(new PublishersPage());
        }

        private void ButtonCancel_Click(object sender, RoutedEventArgs e)
        {
            if (sender is not Button)
            {
                return;
            }

            NavigationService.Navigate(new PublishersPage());
        }

        private void ButtonDelete_Click(object sender, RoutedEventArgs e)
        {
            if (sender is not Button button)
            {
                return;
            }

            DbUtils.DeletePublisher(_publisher.PublisherId);

            NavigationService.Navigate(new PublishersPage());
        }

        private void PrimaryInputLimit_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            if (sender is not TextBox textBox)
            {
                return;
            }

            if (textBox.Text.Length >= Consts.TEXTBOX_PRIMARY_LIMIT)
            {
                e.Handled = true;
            }
        }
    }
}
