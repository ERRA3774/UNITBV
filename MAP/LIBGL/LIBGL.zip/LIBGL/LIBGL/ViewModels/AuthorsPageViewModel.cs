﻿using LIBGL.Databases;
using LIBGL.Utils;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Data;

namespace LIBGL.ViewModels
{
    public class AuthorsPageViewModel : ViewModelBase
    {
        private string _title;
        public string Title
        {
            get
            {
                return _title;
            }
            set
            {
                _title = value;
                OnPropertyChanged(nameof(Title));
            }
        }

        private List<Models.Author> _authors;
        public List<Models.Author> Authors
        {
            get
            {
                return _authors;
            }
            set
            {
                _authors = value;
                OnPropertyChanged(nameof(Authors));
            }
        }

        private readonly ObservableCollection<Models.Author> _allAuthors;
        public ObservableCollection<Models.Author> AllAuthors
        {
            get => _allAuthors;
            set
            {
                OnPropertyChanged(nameof(AllAuthors));
            }
        }

        public ICollectionView AuthorsView { get; private set; }

        public AuthorsPageViewModel()
        {
            _title = Consts.AUTHORS_PAGE_TITLE;
            _authors = DbUtils.GetAllActiveAuthors();
            _allAuthors = new ObservableCollection<Models.Author>(Authors);
            AuthorsView = CollectionViewSource.GetDefaultView(_allAuthors);
        }

        public void FilterAuthors(string inputText)
        {
            inputText = inputText.ToLower();

            AuthorsView.Filter = author =>
            {
                return ((Models.Author)author).FirstName.ToLower().Contains(inputText)
                || ((Models.Author)author).LastName.ToLower().Contains(inputText)
                || ((Models.Author)author).BirthDate.ToString().ToLower().Contains(inputText);
            };
        }
    }
}
