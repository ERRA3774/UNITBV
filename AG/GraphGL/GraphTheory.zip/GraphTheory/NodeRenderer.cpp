#include "NodeRenderer.h"

NodeRenderer::NodeRenderer(Graph& graph) :
	m_graph(graph) {

	_InitNode();
	_InitText();
}

void NodeRenderer::Render(sf::RenderWindow& window, const Node& node) {
	m_nodePosition = sf::Vector2i(node.X, node.Y);
	m_nodeShape.setPosition(static_cast<sf::Vector2f>(m_nodePosition));

	m_nodeText.setString(std::to_string(node.VALUE));

	const float textX = m_nodePosition.x - (m_nodeText.getLocalBounds().width / 2) + m_nodeShape.getRadius() - 2;
	const float textY = m_nodePosition.y + (m_nodeShape.getRadius() / 2);
	m_nodeText.setPosition(textX, textY);

	window.draw(m_nodeShape);
	window.draw(m_nodeText);
}

void NodeRenderer::_InitNode() {
	m_nodeShape.setRadius(C::NODE_RADIUS);
	m_nodeShape.setOrigin(m_nodeShape.getRadius(), m_nodeShape.getRadius());
	m_nodeShape.setFillColor(sf::Color::Black);
	m_nodeShape.setOutlineThickness(3.0f);
	m_nodeShape.setOutlineColor(sf::Color::White);
}

void NodeRenderer::_InitText() {
	if (!m_font.loadFromFile(C::FONT_PATH)) {
		std::cout << "Could not initialize font from path." << std::endl;
	}

	m_nodeText.setFont(m_font);
	m_nodeText.setCharacterSize(22);
	m_nodeText.setStyle(sf::Text::Bold);
	m_nodeText.setOrigin(m_nodeShape.getOrigin());
	m_nodeText.setFillColor(sf::Color::White);
}