﻿using System.Data;
using System.Diagnostics;

using Microsoft.Data.SqlClient;

using LIBGL.Utils;
using LIBGL.Models;
using Microsoft.VisualBasic.ApplicationServices;

namespace LIBGL.Databases
{

    public class DbUtils
    {
        public static readonly string CONNECTION_STRING = System.Configuration.ConfigurationManager.ConnectionStrings["SSMSConnection"].ConnectionString;

        public static bool InsertAuthor(Models.Author author)
        {
            using (SqlConnection connection = new SqlConnection(CONNECTION_STRING))
            {
                SqlCommand sqlCmd = new SqlCommand(Consts.AUTHOR_INSERT, connection);
                sqlCmd.CommandType = CommandType.StoredProcedure;

                sqlCmd.Parameters.Add("@FirstName", SqlDbType.NVarChar);
                sqlCmd.Parameters["@FirstName"].Value = author.FirstName;

                sqlCmd.Parameters.Add("@LastName", SqlDbType.NVarChar);
                sqlCmd.Parameters["@LastName"].Value = author.LastName;

                sqlCmd.Parameters.Add("@BirthDate", SqlDbType.Date);
                sqlCmd.Parameters["@BirthDate"].Value = author.BirthDate;

                try
                {
                    connection.Open();
                    sqlCmd.ExecuteNonQuery();
                    return true;
                }
                catch (Exception ex)
                {
                    Debug.WriteLine($"LIBGL    [W]     Exception caught while adding new author. {ex.Message}");
                    return false;
                }
            }
        }

        public static bool UpdateAuthor(Models.Author author)
        {
            using (SqlConnection connection = new SqlConnection(CONNECTION_STRING))
            {
                SqlCommand sqlCmd = new SqlCommand(Consts.AUTHOR_UPDATE, connection);

                sqlCmd.CommandType = CommandType.StoredProcedure;
                sqlCmd.Parameters.Add("@AuthorId", SqlDbType.Int);
                sqlCmd.Parameters["@AuthorId"].Value = author.AuthorId;

                sqlCmd.Parameters.Add("@FirstName", SqlDbType.NVarChar);
                sqlCmd.Parameters["@FirstName"].Value = author.FirstName;

                sqlCmd.Parameters.Add("@LastName", SqlDbType.NVarChar);
                sqlCmd.Parameters["@LastName"].Value = author.LastName;

                sqlCmd.Parameters.Add("@BirthDate", SqlDbType.Date);
                sqlCmd.Parameters["@BirthDate"].Value = author.BirthDate;

                sqlCmd.Parameters.Add("@Active", SqlDbType.Bit);
                sqlCmd.Parameters["@Active"].Value = author.Active;

                try
                {
                    connection.Open();
                    sqlCmd.ExecuteNonQuery();
                    return true;
                }
                catch (Exception ex)
                {
                    Debug.WriteLine($"LIBGL    [W]     Exception caught while updating author with id: {author.AuthorId}. {ex.Message}");
                    return false;
                }
            }
        }

        public static Models.Author? GetAuthor(int authorId)
        {
            Models.Author? author = null;

            using (SqlConnection connection = new SqlConnection(CONNECTION_STRING))
            {
                SqlCommand sqlCmd = new SqlCommand(Consts.AUTHOR_SELECT, connection);

                sqlCmd.CommandType = CommandType.StoredProcedure;
                sqlCmd.Parameters.Add("@AuthorId", SqlDbType.Int);
                sqlCmd.Parameters["@AuthorId"].Value = authorId;

                try
                {
                    connection.Open();
                    SqlDataReader reader = sqlCmd.ExecuteReader();

                    if (reader.Read())
                    {
                        author = new Author
                        {
                            AuthorId = (int)reader["AuthorId"],
                            FirstName = reader["FirstName"].ToString() ?? string.Empty,
                            LastName = reader["LastName"].ToString() ?? string.Empty,
                            BirthDate = DateOnly.FromDateTime(Convert.ToDateTime(reader["BirthDate"])),
                            Active = Convert.ToBoolean(reader["Active"])
                        };
                    }
                }
                catch (Exception ex)
                {
                    Debug.WriteLine($"LIBGL    [W]     Exception caught while retrieving author with id: {authorId}. {ex.Message}");
                }
            }

            return author;
        }

        public static bool DeleteAuthor(int authorId)
        {
            using (SqlConnection connection = new SqlConnection(CONNECTION_STRING))
            {
                SqlCommand sqlCmd = new SqlCommand(Consts.AUTHOR_DELETE, connection);

                sqlCmd.CommandType = CommandType.StoredProcedure;
                sqlCmd.Parameters.Add("@AuthorId", SqlDbType.Int);
                sqlCmd.Parameters["@AuthorId"].Value = authorId;

                try
                {
                    connection.Open();
                    sqlCmd.ExecuteNonQuery();
                    return true;
                }
                catch (Exception ex)
                {
                    Debug.WriteLine($"LIBGL    [W]     Exception caught while deleting author with id: {authorId}. {ex.Message}");
                    return false;
                }
            }
        }

        public static List<Models.Author> GetAllActiveAuthors()
        {
            List<Models.Author> authors = new List<Models.Author>();

            using (SqlConnection connection = new SqlConnection(CONNECTION_STRING))
            {
                SqlCommand sqlCmd = new SqlCommand(Consts.AUTHOR_ALL_ACTIVE_SELECT, connection);
                sqlCmd.CommandType = CommandType.StoredProcedure;

                try
                {
                    connection.Open();
                    SqlDataReader reader = sqlCmd.ExecuteReader();

                    while (reader.Read())
                    {
                        Models.Author author = new Models.Author
                        {
                            AuthorId = (int)reader["AuthorId"],
                            FirstName = reader["FirstName"].ToString() ?? string.Empty,
                            LastName = reader["LastName"].ToString() ?? string.Empty,
                            BirthDate = DateOnly.FromDateTime(Convert.ToDateTime(reader["BirthDate"])),
                            Active = (bool)reader["Active"]
                        };
                        authors.Add(author);
                    }
                }
                catch (Exception ex)
                {
                    Debug.WriteLine($"LIBGL    [W]     Exception caught while retrieving active authors. {ex.Message}");
                }
            }

            return authors;
        }

        public static List<Models.Author> GetAllAuthors()
        {
            List<Models.Author> authors = new List<Models.Author>();

            using (SqlConnection connection = new SqlConnection(CONNECTION_STRING))
            {
                SqlCommand sqlCmd = new SqlCommand(Consts.AUTHOR_ALL_SELECT, connection);
                sqlCmd.CommandType = CommandType.StoredProcedure;

                try
                {
                    connection.Open();
                    SqlDataReader reader = sqlCmd.ExecuteReader();

                    while (reader.Read())
                    {
                        Models.Author author = new Models.Author
                        {
                            AuthorId = (int)reader["AuthorId"],
                            FirstName = reader["FirstName"].ToString() ?? string.Empty,
                            LastName = reader["LastName"].ToString() ?? string.Empty,
                            BirthDate = DateOnly.FromDateTime(Convert.ToDateTime(reader["BirthDate"])),
                            Active = (bool)reader["Active"]
                        };
                        authors.Add(author);
                    }
                }
                catch (Exception ex)
                {
                    Debug.WriteLine($"LIBGL    [W]     Exception caught while retrieving authors. {ex.Message}");
                }
            }

            return authors;
        }

        public static bool InsertUser(Models.User user)
        {
            using (SqlConnection connection = new SqlConnection(CONNECTION_STRING))
            {
                SqlCommand sqlCmd = new SqlCommand(Consts.USER_INSERT, connection);
                sqlCmd.CommandType = CommandType.StoredProcedure;

                sqlCmd.Parameters.Add("@FirstName", SqlDbType.NVarChar);
                sqlCmd.Parameters["@FirstName"].Value = user.FirstName;

                sqlCmd.Parameters.Add("@LastName", SqlDbType.NVarChar);
                sqlCmd.Parameters["@LastName"].Value = user.LastName;

                sqlCmd.Parameters.Add("@Email", SqlDbType.NVarChar);
                sqlCmd.Parameters["@Email"].Value = user.Email;

                sqlCmd.Parameters.Add("@Phone", SqlDbType.NVarChar);
                sqlCmd.Parameters["@Phone"].Value = user.Phone;

                try
                {
                    connection.Open();
                    sqlCmd.ExecuteNonQuery();
                    return true;
                }
                catch (Exception ex)
                {
                    Debug.WriteLine($"LIBGL    [W]     Exception caught while adding new user. {ex.Message}");
                    return false;
                }
            }
        }

        public static bool UpdateUser(Models.User user)
        {
            using (SqlConnection connection = new SqlConnection(CONNECTION_STRING))
            {
                SqlCommand sqlCmd = new SqlCommand(Consts.USER_UPDATE, connection);

                sqlCmd.CommandType = CommandType.StoredProcedure;
                sqlCmd.Parameters.Add("@UserId", SqlDbType.Int);
                sqlCmd.Parameters["@UserId"].Value = user.UserId;

                sqlCmd.Parameters.Add("@FirstName", SqlDbType.NVarChar);
                sqlCmd.Parameters["@FirstName"].Value = user.FirstName;

                sqlCmd.Parameters.Add("@LastName", SqlDbType.NVarChar);
                sqlCmd.Parameters["@LastName"].Value = user.LastName;

                sqlCmd.Parameters.Add("@Email", SqlDbType.NVarChar);
                sqlCmd.Parameters["@Email"].Value = user.Email;

                sqlCmd.Parameters.Add("@Phone", SqlDbType.NVarChar);
                sqlCmd.Parameters["@Phone"].Value = user.Phone;

                sqlCmd.Parameters.Add("@Active", SqlDbType.Bit);
                sqlCmd.Parameters["@Active"].Value = user.Active;

                try
                {
                    connection.Open();
                    sqlCmd.ExecuteNonQuery();
                    return true;
                }
                catch (Exception ex)
                {
                    Debug.WriteLine($"LIBGL    [W]     Exception caught while updating user with id: {user.UserId}. {ex.Message}");
                    return false;
                }
            }
        }

        public static Models.User? GetUser(int userId)
        {
            Models.User? user = null;

            using (SqlConnection connection = new SqlConnection(CONNECTION_STRING))
            {
                SqlCommand sqlCmd = new SqlCommand(Consts.USER_SELECT, connection);

                sqlCmd.CommandType = CommandType.StoredProcedure;
                sqlCmd.Parameters.Add("@UserId", SqlDbType.Int);
                sqlCmd.Parameters["@UserId"].Value = userId;

                try
                {
                    connection.Open();
                    SqlDataReader reader = sqlCmd.ExecuteReader();

                    if (reader.Read())
                    {
                        user = new Models.User
                        {
                            UserId = (int)reader["UserId"],
                            FirstName = reader["FirstName"].ToString() ?? string.Empty,
                            LastName = reader["LastName"].ToString() ?? string.Empty,
                            Email = reader["Email"].ToString() ?? string.Empty,
                            Phone = reader["Phone"].ToString() ?? string.Empty,
                            Active = Convert.ToBoolean(reader["Active"])
                        };
                    }
                }
                catch (Exception ex)
                {
                    Debug.WriteLine($"LIBGL    [W]     Exception caught while retrieving user with id: {userId}. {ex.Message}");
                }
            }

            return user;
        }

        public static bool DeleteUser(int userId)
        {
            using (SqlConnection connection = new SqlConnection(CONNECTION_STRING))
            {
                SqlCommand sqlCmd = new SqlCommand(Consts.USER_DELETE, connection);

                sqlCmd.CommandType = CommandType.StoredProcedure;
                sqlCmd.Parameters.Add("@UserId", SqlDbType.Int);
                sqlCmd.Parameters["@UserId"].Value = userId;

                try
                {
                    connection.Open();
                    sqlCmd.ExecuteNonQuery();
                    return true;
                }
                catch (Exception ex)
                {
                    Debug.WriteLine($"LIBGL    [W]     Exception caught while deleting user with id: {userId}. {ex.Message}");
                    return false;
                }
            }
        }

        public static List<Models.User> GetAllActiveUsers()
        {
            List<Models.User> users = new List<Models.User>();

            using (SqlConnection connection = new SqlConnection(CONNECTION_STRING))
            {
                SqlCommand sqlCmd = new SqlCommand(Consts.USER_ALL_ACTIVE_SELECT, connection);
                sqlCmd.CommandType = CommandType.StoredProcedure;

                try
                {
                    connection.Open();
                    SqlDataReader reader = sqlCmd.ExecuteReader();

                    while (reader.Read())
                    {
                        Models.User user = new Models.User
                        {
                            UserId = (int)reader["UserId"],
                            FirstName = reader["FirstName"].ToString() ?? string.Empty,
                            LastName = reader["LastName"].ToString() ?? string.Empty,
                            Email = reader["Email"].ToString() ?? string.Empty,
                            Phone = reader["Phone"].ToString() ?? string.Empty,
                            Active = (bool)reader["Active"]
                        };
                        users.Add(user);
                    }
                }
                catch (Exception ex)
                {
                    Debug.WriteLine($"LIBGL    [W]     Exception caught while retrieving active users. {ex.Message}");
                }
            }

            return users;
        }

        public static List<Models.User> GetAllUsers()
        {
            List<Models.User> users = new List<Models.User>();

            using (SqlConnection connection = new SqlConnection(CONNECTION_STRING))
            {
                SqlCommand sqlCmd = new SqlCommand(Consts.USER_ALL_SELECT, connection);
                sqlCmd.CommandType = CommandType.StoredProcedure;

                try
                {
                    connection.Open();
                    SqlDataReader reader = sqlCmd.ExecuteReader();

                    while (reader.Read())
                    {
                        Models.User user = new Models.User
                        {
                            UserId = (int)reader["UserId"],
                            FirstName = reader["FirstName"].ToString() ?? string.Empty,
                            LastName = reader["LastName"].ToString() ?? string.Empty,
                            Email = reader["Email"].ToString() ?? string.Empty,
                            Phone = reader["Phone"].ToString() ?? string.Empty,
                            Active = (bool)reader["Active"]
                        };
                        users.Add(user);
                    }
                }
                catch (Exception ex)
                {
                    Debug.WriteLine($"LIBGL    [W]     Exception caught while retrieving users. {ex.Message}");
                }
            }

            return users;
        }

        public static bool InsertPublisher(Models.Publisher publisher)
        {
            using (SqlConnection connection = new SqlConnection(CONNECTION_STRING))
            {
                SqlCommand sqlCmd = new SqlCommand(Consts.PUBLISHER_INSERT, connection);
                sqlCmd.CommandType = CommandType.StoredProcedure;

                sqlCmd.Parameters.Add("@Name", SqlDbType.NVarChar);
                sqlCmd.Parameters["@Name"].Value = publisher.Name;

                sqlCmd.Parameters.Add("@Address", SqlDbType.NVarChar);
                sqlCmd.Parameters["@Address"].Value = publisher.Address;

                try
                {
                    connection.Open();
                    sqlCmd.ExecuteNonQuery();
                    return true;
                }
                catch (Exception ex)
                {
                    Debug.WriteLine($"LIBGL    [W]     Exception caught while adding new publisher. {ex.Message}");
                    return false;
                }
            }
        }

        public static bool UpdatePublisher(Models.Publisher publisher)
        {
            using (SqlConnection connection = new SqlConnection(CONNECTION_STRING))
            {
                SqlCommand sqlCmd = new SqlCommand(Consts.PUBLISHER_UPDATE, connection);
                sqlCmd.CommandType = CommandType.StoredProcedure;


                sqlCmd.Parameters.Add("@PublisherId", SqlDbType.Int);
                sqlCmd.Parameters["@PublisherId"].Value = publisher.PublisherId;

                sqlCmd.Parameters.Add("@Name", SqlDbType.NVarChar);
                sqlCmd.Parameters["@Name"].Value = publisher.Name;

                sqlCmd.Parameters.Add("@Address", SqlDbType.NVarChar);
                sqlCmd.Parameters["@Address"].Value = publisher.Address;

                sqlCmd.Parameters.Add("@Active", SqlDbType.Bit);
                sqlCmd.Parameters["@Active"].Value = publisher.Active;

                try
                {
                    connection.Open();
                    sqlCmd.ExecuteNonQuery();
                    return true;
                }
                catch (Exception ex)
                {
                    Debug.WriteLine($"LIBGL    [W]     Exception caught while updating publisher. {ex.Message}");
                    return false;
                }
            }
        }

        public static Models.Publisher? GetPublisher(int publisherId)
        {
            Models.Publisher? publisher = null;

            using (SqlConnection connection = new SqlConnection(CONNECTION_STRING))
            {
                SqlCommand sqlCmd = new SqlCommand(Consts.PUBLISHER_SELECT, connection);

                sqlCmd.CommandType = CommandType.StoredProcedure;
                sqlCmd.Parameters.Add("@PublisherId", SqlDbType.Int);
                sqlCmd.Parameters["@PublisherId"].Value = publisherId;

                try
                {
                    connection.Open();
                    SqlDataReader reader = sqlCmd.ExecuteReader();

                    if (reader.Read())
                    {
                        publisher = new Models.Publisher
                        {
                            PublisherId = (int)reader["PublisherId"],
                            Name = reader["Name"].ToString() ?? string.Empty,
                            Address = reader["Address"].ToString() ?? string.Empty,
                            Active = Convert.ToBoolean(reader["Active"])
                        };
                    }
                }
                catch (Exception ex)
                {
                    Debug.WriteLine($"LIBGL    [W]     Exception caught while retrieving publisher with id: {publisherId}. {ex.Message}");
                }
            }

            return publisher;
        }

        public static bool DeletePublisher(int publisherId)
        {
            using (SqlConnection connection = new SqlConnection(CONNECTION_STRING))
            {
                SqlCommand sqlCmd = new SqlCommand(Consts.PUBLISHER_DELETE, connection);

                sqlCmd.CommandType = CommandType.StoredProcedure;
                sqlCmd.Parameters.Add("@PublisherId", SqlDbType.Int);
                sqlCmd.Parameters["@PublisherId"].Value = publisherId;

                try
                {
                    connection.Open();
                    sqlCmd.ExecuteNonQuery();
                    return true;
                }
                catch (Exception ex)
                {
                    Debug.WriteLine($"LIBGL    [W]     Exception caught while deleting user with id: {publisherId}. {ex.Message}");
                    return false;
                }
            }
        }

        public static List<Models.Publisher> GetAllPublishers()
        {
            List<Models.Publisher> publishers = new List<Models.Publisher>();

            using (SqlConnection connection = new SqlConnection(CONNECTION_STRING))
            {
                SqlCommand sqlCmd = new SqlCommand(Consts.PUBLISHER_ALL_SELECT, connection);
                sqlCmd.CommandType = CommandType.StoredProcedure;

                try
                {
                    connection.Open();
                    SqlDataReader reader = sqlCmd.ExecuteReader();

                    while (reader.Read())
                    {
                        Models.Publisher publisher = new Models.Publisher
                        {
                            PublisherId = (int)reader["PublisherId"],
                            Name = reader["Name"].ToString() ?? string.Empty,
                            Address = reader["Address"].ToString() ?? string.Empty,
                            Active = (bool)reader["Active"]
                        };
                        publishers.Add(publisher);
                    }
                }
                catch (Exception ex)
                {
                    Debug.WriteLine($"LIBGL    [W]     Exception caught while retrieving publishers. {ex.Message}");
                }
            }

            return publishers;
        }

        public static List<Models.Publisher> GetAllActivePublishers()
        {
            List<Models.Publisher> publishers = new List<Models.Publisher>();

            using (SqlConnection connection = new SqlConnection(CONNECTION_STRING))
            {
                SqlCommand sqlCmd = new SqlCommand(Consts.PUBLISHER_ALL_ACTIVE_SELECT, connection);
                sqlCmd.CommandType = CommandType.StoredProcedure;

                try
                {
                    connection.Open();
                    SqlDataReader reader = sqlCmd.ExecuteReader();

                    while (reader.Read())
                    {
                        Models.Publisher publisher = new Models.Publisher
                        {
                            PublisherId = (int)reader["PublisherId"],
                            Name = reader["Name"].ToString() ?? string.Empty,
                            Address = reader["Address"].ToString() ?? string.Empty,
                            Active = (bool)reader["Active"]
                        };
                        publishers.Add(publisher);
                    }
                }
                catch (Exception ex)
                {
                    Debug.WriteLine($"LIBGL    [W]     Exception caught while retrieving publishers. {ex.Message}");
                }
            }

            return publishers;
        }

        public static List<Models.AuthorBook> GetAllAuthorBooks()
        {
            List<Models.AuthorBook> authorBooks = new List<Models.AuthorBook>();

            using (SqlConnection connection = new SqlConnection(CONNECTION_STRING))
            {
                SqlCommand sqlCmd = new SqlCommand(Consts.AUTHOR_BOOK_ALL_SELECT, connection);
                sqlCmd.CommandType = CommandType.StoredProcedure;

                try
                {
                    connection.Open();
                    SqlDataReader reader = sqlCmd.ExecuteReader();

                    while (reader.Read())
                    {
                        Models.AuthorBook authorBook = new Models.AuthorBook
                        {
                            Id = (int)reader["Id"],
                            AuthorId = (int)reader["AuthorId"],
                            BookId = (int)reader["BookId"],
                            NumberInList = (int)reader["NumberInList"]
                        };
                        authorBooks.Add(authorBook);
                    }
                }
                catch (Exception ex)
                {
                    Debug.WriteLine($"LIBGL    [W]     Exception caught while retrieving author books. {ex.Message}");
                }
            }


            return authorBooks;
        }

        public static int InsertBook(Models.Book book)
        {
            using (SqlConnection connection = new SqlConnection(CONNECTION_STRING))
            {
                SqlCommand sqlCmd = new SqlCommand(Consts.BOOK_INSERT, connection);
                sqlCmd.CommandType = CommandType.StoredProcedure;

                sqlCmd.Parameters.Add("@Title", SqlDbType.NVarChar);
                sqlCmd.Parameters["@Title"].Value = book.Title;

                sqlCmd.Parameters.Add("@BookTypeId", SqlDbType.Int);
                sqlCmd.Parameters["@BookTypeId"].Value = book.BookTypeId;

                sqlCmd.Parameters.Add("@PublisherId", SqlDbType.Int);
                sqlCmd.Parameters["@PublisherId"].Value = book.PublisherId;

                sqlCmd.Parameters.Add("@Stock", SqlDbType.Int);
                sqlCmd.Parameters["@Stock"].Value = book.Stock;

                sqlCmd.Parameters.Add("@PublishYear", SqlDbType.Int);
                sqlCmd.Parameters["@PublishYear"].Value = book.PublishYear;

                try
                {
                    connection.Open();
                    object result = sqlCmd.ExecuteScalar();
                    
                    if (result != null)
                    {
                        return Convert.ToInt32(result);
                    }
                    else
                    {
                        Debug.WriteLine("LIBGL    [W]     No BookId returned after inserting new book.");
                        return int.MinValue;
                    }

                }
                catch (Exception ex)
                {
                    Debug.WriteLine($"LIBGL    [W]     Exception caught while adding new book. {ex.Message}");
                    return int.MinValue;
                }
            }
        }

        public static bool UpdateBook(Models.Book book)
        {
            using (SqlConnection connection = new SqlConnection(CONNECTION_STRING))
            {
                SqlCommand sqlCmd = new SqlCommand(Consts.BOOK_UPDATE, connection);

                sqlCmd.CommandType = CommandType.StoredProcedure;
                sqlCmd.Parameters.Add("@BookId", SqlDbType.Int);
                sqlCmd.Parameters["@BookId"].Value = book.BookId;

                sqlCmd.Parameters.Add("@BookTypeId", SqlDbType.Int);
                sqlCmd.Parameters["@BookTypeId"].Value = book.BookTypeId;

                sqlCmd.Parameters.Add("@PublisherId", SqlDbType.Int);
                sqlCmd.Parameters["@PublisherId"].Value = book.PublisherId;

                sqlCmd.Parameters.Add("@Title", SqlDbType.NVarChar);
                sqlCmd.Parameters["@Title"].Value = book.Title;

                sqlCmd.Parameters.Add("@PublishYear", SqlDbType.Int);
                sqlCmd.Parameters["@PublishYear"].Value = book.PublishYear;

                sqlCmd.Parameters.Add("@Stock", SqlDbType.Int);
                sqlCmd.Parameters["@Stock"].Value = book.Stock;

                sqlCmd.Parameters.Add("@Active", SqlDbType.Bit);
                sqlCmd.Parameters["@Active"].Value = book.Active;

                try
                {
                    connection.Open();
                    sqlCmd.ExecuteNonQuery();
                    return true;
                }
                catch (Exception ex)
                {
                    Debug.WriteLine($"LIBGL    [W]     Exception caught while updating book with id: {book.BookId}. {ex.Message}");
                    return false;
                }
            }
        }

        public static Models.Book? GetBook(int bookId)
        {
            Models.Book? book = null;

            using (SqlConnection connection = new SqlConnection(CONNECTION_STRING))
            {
                SqlCommand sqlCmd = new SqlCommand(Consts.BOOK_SELECT, connection);

                sqlCmd.CommandType = CommandType.StoredProcedure;
                sqlCmd.Parameters.Add("@BookId", SqlDbType.Int);
                sqlCmd.Parameters["@BookId"].Value = bookId;

                try
                {
                    connection.Open();
                    SqlDataReader reader = sqlCmd.ExecuteReader();

                    if (reader.Read())
                    {
                        book = new Models.Book
                        {
                            BookId = (int)(reader["BookId"]),
                            BookTypeId = (int)reader["BookTypeId"],
                            PublisherId = (int)reader["PublisherId"],
                            Title = reader["Title"].ToString() ?? string.Empty,
                            PublishYear = (int)reader["PublishYear"],
                            Stock = (int)reader["Stock"],
                            Active = (bool)reader["Active"]
                        };
                    }
                }
                catch (Exception ex)
                {
                    Debug.WriteLine($"LIBGL    [W]     Exception caught while retrieving book with id: {bookId}. {ex.Message}");
                }
            }

            return book;
        }

        public static bool DeleteBook(int bookId)
        {
            using (SqlConnection connection = new SqlConnection(CONNECTION_STRING))
            {
                SqlCommand sqlCmd = new SqlCommand(Consts.BOOK_DELETE, connection);

                sqlCmd.CommandType = CommandType.StoredProcedure;
                sqlCmd.Parameters.Add("@BookId", SqlDbType.Int);
                sqlCmd.Parameters["@BookId"].Value = bookId;

                try
                {
                    connection.Open();
                    sqlCmd.ExecuteNonQuery();
                    return true;
                }
                catch (Exception ex)
                {
                    Debug.WriteLine($"LIBGL    [W]     Exception caught while deleting book with id: {bookId}. {ex.Message}");
                    return false;
                }
            }
        }

        public static List<Models.Book> GetAllActiveBooks()
        {
            List<Models.Book> books = new List<Models.Book>();

            using (SqlConnection connection = new SqlConnection(CONNECTION_STRING))
            {
                SqlCommand sqlCmd = new SqlCommand(Consts.BOOK_ALL_ACTIVE_SELECT, connection);
                sqlCmd.CommandType = CommandType.StoredProcedure;

                try
                {
                    connection.Open();
                    SqlDataReader reader = sqlCmd.ExecuteReader();

                    while (reader.Read())
                    {
                        Models.Book book = new Models.Book
                        {
                            BookId = (int)(reader["BookId"]),
                            BookTypeId = (int)reader["BookTypeId"],
                            PublisherId = (int)reader["PublisherId"],
                            Title = reader["Title"].ToString() ?? string.Empty,
                            PublishYear = (int)reader["PublishYear"],
                            Stock = (int)reader["Stock"],
                            Active = (bool)reader["Active"]
                        };
                        books.Add(book);
                    }
                }
                catch (Exception ex)
                {
                    Debug.WriteLine($"LIBGL    [W]     Exception caught while retrieving books. {ex.Message}");
                }
            }

            return books;
        }

        public static List<Models.Book> GetAllBooks()
        {
            List<Models.Book> books = new List<Models.Book>();

            using (SqlConnection connection = new SqlConnection(CONNECTION_STRING))
            {
                SqlCommand sqlCmd = new SqlCommand(Consts.BOOK_ALL_SELECT, connection);
                sqlCmd.CommandType = CommandType.StoredProcedure;

                try
                {
                    connection.Open();
                    SqlDataReader reader = sqlCmd.ExecuteReader();

                    while (reader.Read())
                    {
                        Models.Book book = new Models.Book
                        {
                            BookId = (int)(reader["BookId"]),
                            BookTypeId = (int)reader["BookTypeId"],
                            PublisherId = (int)reader["PublisherId"],
                            Title = reader["Title"].ToString() ?? string.Empty,
                            PublishYear = (int)reader["PublishYear"],
                            Stock = (int)reader["Stock"],
                            Active = (bool)reader["Active"]
                        };
                        books.Add(book);
                    }
                }
                catch (Exception ex)
                {
                    Debug.WriteLine($"LIBGL    [W]     Exception caught while retrieving books. {ex.Message}");
                }
            }

            return books;
        }

        public static bool InsertBookGenre(Models.BookType bookType)
        {
            using (SqlConnection connection = new SqlConnection(CONNECTION_STRING))
            {
                SqlCommand sqlCmd = new SqlCommand(Consts.BOOK_TYPE_INSERT, connection);
                sqlCmd.CommandType = CommandType.StoredProcedure;

                sqlCmd.Parameters.Add("@Name", SqlDbType.NVarChar);
                sqlCmd.Parameters["@Name"].Value = bookType.Name;

                try
                {
                    connection.Open();
                    sqlCmd.ExecuteNonQuery();
                    return true;
                }
                catch (Exception ex)
                {
                    Debug.WriteLine($"[W] Exception caught while adding new book type. {ex.Message}");
                    return false;
                }
            }
        }

        public static bool UpdateBookGenre(Models.BookType bookType)
        {
            using (SqlConnection connection = new SqlConnection(CONNECTION_STRING))
            {
                SqlCommand sqlCmd = new SqlCommand(Consts.BOOK_TYPE_UPDATE, connection);

                sqlCmd.CommandType = CommandType.StoredProcedure;
                sqlCmd.Parameters.Add("@BookTypeId", SqlDbType.Int);
                sqlCmd.Parameters["@BookTypeId"].Value = bookType.BookTypeId;

                sqlCmd.Parameters.Add("@Name", SqlDbType.NVarChar);
                sqlCmd.Parameters["@Name"].Value = bookType.Name;

                sqlCmd.Parameters.Add("@Active", SqlDbType.Bit);
                sqlCmd.Parameters["@Active"].Value = bookType.Active;

                try
                {
                    connection.Open();
                    sqlCmd.ExecuteNonQuery();
                    return true;
                }
                catch (Exception ex)
                {
                    Debug.WriteLine($"LIBGL    [W]     Exception caught while updating book type with id: {bookType.BookTypeId}. {ex.Message}");
                    return false;
                }
            }
        }

        public static Models.BookType? GetBookGenre(int bookTypeId)
        {
                Models.BookType? bookType = null;

                using (SqlConnection connection = new SqlConnection(CONNECTION_STRING))
                {
                    SqlCommand sqlCmd = new SqlCommand(Consts.BOOK_TYPE_SELECT, connection);

                    sqlCmd.CommandType = CommandType.StoredProcedure;
                    sqlCmd.Parameters.Add("@BookTypeId", SqlDbType.Int);
                    sqlCmd.Parameters["@BookTypeId"].Value = bookTypeId;

                    try
                    {
                        connection.Open();
                        SqlDataReader reader = sqlCmd.ExecuteReader();

                        if (reader.Read())
                        {
                            bookType = new Models.BookType
                            {
                                BookTypeId = (int)reader["BookTypeId"],
                                Name = reader["Name"].ToString() ?? string.Empty,
                                Active = Convert.ToBoolean(reader["Active"])
                            };
                        }
                    }
                    catch (Exception ex)
                    {
                        Debug.WriteLine($"LIBGL    [W]     Exception caught while retrieving book type with id: {bookTypeId}. {ex.Message}");
                    }
                }

                return bookType;
            }

        public static bool DeleteBookGenre(int bookTypeId)
        {
            using (SqlConnection connection = new SqlConnection(CONNECTION_STRING))
            {
                SqlCommand sqlCmd = new SqlCommand(Consts.BOOK_TYPE_DELETE, connection);

                sqlCmd.CommandType = CommandType.StoredProcedure;
                sqlCmd.Parameters.Add("@BookTypeId", SqlDbType.Int);
                sqlCmd.Parameters["@BookTypeId"].Value = bookTypeId;

                try
                {
                    connection.Open();
                    sqlCmd.ExecuteNonQuery();
                    return true;
                }
                catch (Exception ex)
                {
                    Debug.WriteLine($"LIBGL    [W]     Exception caught while deleting book type with id: {bookTypeId}. {ex.Message}");
                    return false;
                }
            }
        }

        public static List<Models.BookType> GetAllActiveBookGenres()
        {
            List<Models.BookType> bookTypes = new List<Models.BookType>();

            using (SqlConnection connection = new SqlConnection(CONNECTION_STRING))
            {
                SqlCommand sqlCmd = new SqlCommand(Consts.BOOK_TYPE_ALL_ACTIVE_SELECT, connection);
                sqlCmd.CommandType = CommandType.StoredProcedure;

                try
                {
                    connection.Open();
                    SqlDataReader reader = sqlCmd.ExecuteReader();

                    while (reader.Read())
                    {
                        Models.BookType bookType = new Models.BookType
                        {
                            BookTypeId = (int)reader["BookTypeId"],
                            Name = reader["Name"].ToString() ?? string.Empty,
                            Active = (bool)reader["Active"],
                        };
                        bookTypes.Add(bookType);
                    }
                }
                catch (Exception ex)
                {
                    Debug.WriteLine($"LIBGL    [W]     Exception caught while retrieving active books types. {ex.Message}");
                }
            }

            return bookTypes;
        }

        public static List<Models.BookType> GetAllBookGenres()
        {
            List<Models.BookType> bookTypes = new List<Models.BookType>();

            using (SqlConnection connection = new SqlConnection(CONNECTION_STRING))
            {
                SqlCommand sqlCmd = new SqlCommand(Consts.BOOK_TYPE_ALL_SELECT, connection);
                sqlCmd.CommandType = CommandType.StoredProcedure;

                try
                {
                    connection.Open();
                    SqlDataReader reader = sqlCmd.ExecuteReader();

                    while (reader.Read())
                    {
                        Models.BookType bookType = new Models.BookType
                        {
                            BookTypeId = (int)reader["BookTypeId"],
                            Name = reader["Name"].ToString() ?? string.Empty,
                            Active = (bool)reader["Active"],
                        };
                        bookTypes.Add(bookType);
                    }
                }
                catch (Exception ex)
                {
                    Debug.WriteLine($"LIBGL    [W]     Exception caught while retrieving books types. {ex.Message}");
                }
            }

            return bookTypes;
        }

        public static List<Models.Author> GetBookAuthorsOf(Models.Book book)
        {
            List<Models.Author> booksAuthors = new List<Models.Author>();

            using (SqlConnection connection = new SqlConnection(CONNECTION_STRING))
            {
                SqlCommand sqlCmd = new SqlCommand(Consts.BOOK_AUTHOR_SELECT, connection);
                sqlCmd.CommandType = CommandType.StoredProcedure;

                sqlCmd.Parameters.Add("@BookId", SqlDbType.Int);
                sqlCmd.Parameters["@BookId"].Value = book.BookId;

                try
                {
                    connection.Open();
                    SqlDataReader reader = sqlCmd.ExecuteReader();

                    while (reader.Read())
                    {
                        Models.Author author = new Models.Author
                        {
                            AuthorId = (int)reader["AuthorId"],
                            FirstName = reader["FirstName"].ToString() ?? string.Empty,
                            LastName = reader["LastName"].ToString() ?? string.Empty,
                            BirthDate = DateOnly.FromDateTime(Convert.ToDateTime(reader["BirthDate"])),
                            Active = (bool)reader["Active"]
                        };

                        booksAuthors.Add(author);
                    }
                }
                catch (Exception ex)
                {
                    Debug.WriteLine($"LIBGL    [W]     Exception caught while retrieving book authors types. {ex.Message}");
                }
            }

            return booksAuthors;
        }

        public static bool InsertAuthorBook(Models.AuthorBook authorBook)
        {
            using (SqlConnection connection = new SqlConnection(CONNECTION_STRING))
            {
                SqlCommand sqlCmd = new SqlCommand(Consts.AUTHOR_BOOK_INSERT, connection);
                sqlCmd.CommandType = CommandType.StoredProcedure;

                sqlCmd.Parameters.Add("@AuthorId", SqlDbType.Int);
                sqlCmd.Parameters["@AuthorId"].Value = authorBook.AuthorId;

                sqlCmd.Parameters.Add("@BookId", SqlDbType.Int);
                sqlCmd.Parameters["@BookId"].Value = authorBook.BookId;

                sqlCmd.Parameters.Add("@NumberInList", SqlDbType.Int);
                sqlCmd.Parameters["@NumberInList"].Value = authorBook.NumberInList;

                try
                {
                    connection.Open();
                    sqlCmd.ExecuteNonQuery();
                    return true;
                }
                catch (Exception ex)
                {
                    Debug.WriteLine($"LIBGL    [W]     Exception caught while adding new author book. {ex.Message}");
                    return false;
                }
            }
        }
        

        public static List<Models.UserBook> GetAllUserBooks()
        {
            List<Models.UserBook> userBooks = new List<Models.UserBook>();

            using (SqlConnection connection = new SqlConnection(CONNECTION_STRING))
            {
                SqlCommand sqlCmd = new SqlCommand(Consts.USER_BOOK_ALL_SELECT, connection);
                sqlCmd.CommandType = CommandType.StoredProcedure;

                try
                {
                    connection.Open();
                    SqlDataReader reader = sqlCmd.ExecuteReader();

                    while (reader.Read())
                    {
                        Models.UserBook userBook = new Models.UserBook
                        {
                            Id = (int)reader["Id"],
                            UserId = (int)reader["UserId"],
                            BookId = (int)reader["BookId"],
                            StartDate = DateOnly.FromDateTime(Convert.ToDateTime(reader["StartDate"])),
                            EndDate = DateOnly.FromDateTime(Convert.ToDateTime(reader["ReturnDate"])),
                            Active = (bool)reader["Active"]
                        };
                        userBooks.Add(userBook);
                    }
                }
                catch (Exception ex)
                {
                    Debug.WriteLine($"LIBGL    [W]     Exception caught while retrieving user books. {ex.Message}");
                }
            }

            return userBooks;
        }

        // TODO
        public static List<Models.UserBook> GetAllActiveUserBooks()
        {
            return [];
        }

        // TODO
        public static List<Models.Book> GetBorrowedBooks()
        {
            return [];
        }

        // TODO
        public static List<Models.User> GetBorrowerUsers()
        {
            return [];
        }


    }
}
