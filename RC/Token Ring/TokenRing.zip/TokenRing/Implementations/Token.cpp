#include "../Headers/Token.h"

Token::Token() : Sender(std::string()), Destination(std::string()), Message(std::string()) {}

Token::Token(std::string sender, std::string destination, std::string message) : Sender(sender), Destination(destination), Message(message) {}