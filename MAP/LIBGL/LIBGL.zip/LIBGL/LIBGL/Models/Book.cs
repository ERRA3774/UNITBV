﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LIBGL.Models
{
    public class Book
    {
        public int BookId { get; set; }
        public int BookTypeId { get; set; }
        public int PublisherId { get; set; }
        public string Title { get; set; }
        public int PublishYear { get; set; }
        public int Stock { get; set; }
        public bool Active { get; set; }

        public Book()
        {
            BookId = int.MinValue;
            BookTypeId = int.MinValue;
            PublisherId = int.MinValue;
            Title = string.Empty;
            PublishYear = 2024;
            Stock = 0;
            Active = false;
        }
    }
}
