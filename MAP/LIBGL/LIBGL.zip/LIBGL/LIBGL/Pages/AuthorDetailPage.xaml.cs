﻿using LIBGL.Databases;
using LIBGL.Utils;
using LIBGL.ViewModels;
using Microsoft.IdentityModel.Tokens;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace LIBGL.Pages
{
    public partial class AuthorDetailPage : Page
    {
        private readonly Models.Author _author;
        public AuthorDetailsViewModel AuthorDetailsViewModel { get; }

        public AuthorDetailPage(AuthorDetailsViewModel authorDetailsViewModel)
        {
            InitializeComponent();
            AuthorDetailsViewModel = authorDetailsViewModel;
            DataContext = AuthorDetailsViewModel;

            _author = authorDetailsViewModel.Author;

            if (_author.AuthorId.Equals(int.MinValue))
            {
                ButtonDelete.Visibility = Visibility.Hidden;
                ButtonSave.Content = Consts.ADD_TEXT;
                AuthorDetailsHeader.Text = Consts.AUTHOR_ADD_TEXT;
            }
        }

        private void ButtonSave_Click(object sender, RoutedEventArgs e)
        {
            if (sender is not Button button)
            {
                return;
            }

            Models.Author author = new Models.Author
            {
                FirstName = TextBoxFirstName.Text,
                LastName = TextBoxLastName.Text,
                BirthDate = DateOnly.FromDateTime(DatePickerBirthDate.SelectedDate.Value),
            };

            if (_author.AuthorId.Equals(int.MinValue))
            {
                DbUtils.InsertAuthor(author);
            } 
            else
            {
                author.AuthorId = _author.AuthorId;
                author.Active = _author.Active;
                DbUtils.UpdateAuthor(author);
            }
            
            NavigationService.Navigate(new AuthorsPage());
        }

        private void ButtonCancel_Click(object sender, RoutedEventArgs e)
        {
            if (sender is not Button)
            {
                return;
            }

            NavigationService.Navigate(new AuthorsPage());
        }

        private void ButtonDelete_Click(object sender, RoutedEventArgs e)
        {
            if (sender is not Button button)
            {
                return;
            }

            DbUtils.DeleteAuthor(_author.AuthorId);

            NavigationService.Navigate(new AuthorsPage());
        }

        private void PrimaryInputLimit_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            if (sender is not TextBox textBox)
            {
                return;
            }

            if (textBox.Text.Length >= Consts.TEXTBOX_PRIMARY_LIMIT)
            {
                e.Handled = true;
            }
        }
    }
}
