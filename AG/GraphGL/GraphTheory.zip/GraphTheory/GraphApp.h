#pragma once

#include <SFML/Graphics.hpp>
#include <iostream>
#include <vector>
#include <string>

#include "Constants.h"
#include "Graph.h"
#include "NodeRenderer.h"
#include "EdgeRenderer.h"
#include "GraphGUI.h"

enum class AppMode {
	Default,
	Create,
	Move,
	Connect,
	Traverse,
};

enum class Traversal {
	None,
	ShortPath,
	Prim,
	Kruskal,
	Dijkstra,
	BellmanFord,
	FloydWarshall,
};

class GraphApp {
	using C = Constants;

public:
	GraphApp(Graph& graph);

	void Run();

private:
	void _OnMouseMoved();

	void _OnMouseButtonPressed(sf::Event& mouseEvent);
	void _OnMouseButtonReleased(sf::Event& mouseEvent);

	void _OnMouseLeft();
	void _OnMouseRight();

	void _OnMouseLeftReleased();

	void _OnKeyPressed(sf::Event& keyEvent);

	void _SwitchMode(AppMode newMode);
	void _SwitchTraversal(Traversal newTraversal);

public:
	Node PATH_START_NODE;
	Node PATH_END_NODE;

private:
	Graph& m_graph;
	GraphGUI m_gui;

	NodeRenderer m_nodeRenderer;
	EdgeRenderer m_edgeRenderer;

	sf::RenderWindow m_window;

	AppMode m_currentMode; 
	Traversal m_currentTraversal;
};
