#pragma once

#include <vector>
#include <queue>
#include <unordered_map>

#include "../Headers/Token.h"
#include "../Headers/Computer.h"

class TokenRing
{
public:
	bool SenderFlag;
	bool DestinationFlag;
	Token CurrentToken;
	std::queue<Token> Tokens;
	std::vector<Computer> Computers;

	TokenRing();
	TokenRing(std::initializer_list<Computer> computers, std::initializer_list<Token> tokens);

	void NextToken();
};

