﻿using LIBGL.Commands;
using LIBGL.Databases;
using LIBGL.Models;
using Microsoft.IdentityModel.Tokens;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Input;

namespace LIBGL.ViewModels
{
    public class BookDetailsViewModel : ViewModelBase
    {
        private readonly BooksPageViewModel _parent;

        private Models.Book _book;
        public Models.Book Book
        {
            get
            {
                return _book;
            }
            set
            {
                _book = value;
                OnPropertyChanged(nameof(Book));
            }
        }

        private string _bookTitleBoxText;
        public string BookTitleBoxText
        {
            get
            {
                return _bookTitleBoxText;
            }
            set
            {
                _bookTitleBoxText = value;
                OnPropertyChanged(nameof(BookTitleBoxText));
                UpdateCanClickSaveButton();
            }
        }

        private readonly List<Models.Author> _bookAuthors;
        public List<Models.Author> BookAuthors 
        { 
            get
            {
                return _bookAuthors;
            }
        }

        private readonly List<Models.Author> _currentBooksAuthors;
        public List<Models.Author> CurrentBooksAuthors
        {
            get
            {
                return _currentBooksAuthors;
            }
        }

        private readonly List<Models.BookType> _bookGenres;
        public List<Models.BookType> BookGenres
        {
            get
            {
                return _bookGenres;
            }
        }

        private readonly List<Models.Publisher> _bookPublishers;
        public List<Models.Publisher> BookPublishers
        {
            get
            {
                return _bookPublishers;
            }
        }

        public List<string> AllAuthorsLastNames { get; }

        public List<string> AllBookGenresNames { get; }

        public List<string> AllBookPublishersNames { get; }

        private bool _canClickSaveButton;
        public bool CanClickSaveButton
        {
            get { return _canClickSaveButton; }
            set
            {
                _canClickSaveButton = value;
                OnPropertyChanged(nameof(CanClickSaveButton));
            }
        }

        private ObservableCollection<string> _checkedAuthors;
        public ObservableCollection<string> CheckedAuthors
        {
            get => _checkedAuthors;
            set
            {
                _checkedAuthors = value;
                OnPropertyChanged(nameof(CheckedAuthors));
                UpdateCanClickSaveButton();
            }
        }

        private ObservableCollection<string> _uncheckedAuthors;
        public ObservableCollection<string> UncheckedAuthors
        {
            get => _uncheckedAuthors;
            set
            {
                _uncheckedAuthors = value;
                OnPropertyChanged(nameof(UncheckedAuthors));
                UpdateCanClickSaveButton();
            }
        }

        private string _bookGenreSelectedItem;
        public string BookGenreSelectedItem
        {
            get
            {
                return _bookGenreSelectedItem;
            }
            set
            {
                _bookGenreSelectedItem = value;
                OnPropertyChanged(nameof(BookGenreSelectedItem));
                UpdateCanClickSaveButton();
            }
        }

        private string _bookPublisherSelectedItem;
        public string BookPublisherSelectedItem
        {
            get
            {
                return _bookPublisherSelectedItem;
            }
            set
            {
                _bookPublisherSelectedItem = value;
                OnPropertyChanged(nameof(BookPublisherSelectedItem));
                UpdateCanClickSaveButton();
            }
        }
        private string _bookStockBoxText;
        public string BookStockBoxText
        {
            get
            {
                return _bookStockBoxText;
            }
            set
            {
                _bookStockBoxText = value;
                OnPropertyChanged(nameof(BookStockBoxText));
                UpdateCanClickSaveButton();
            }
        }

        private string _bookPublishYearBoxText;
        public string BookPublishYearBoxText
        {
            get
            {
                return _bookPublishYearBoxText;
            }
            set
            {
                _bookPublishYearBoxText = value;
                OnPropertyChanged(nameof(BookPublishYearBoxText));
                UpdateCanClickSaveButton();
            }
        }

        public BookDetailsViewModel(BooksPageViewModel parent, Models.Book book)
        {
            _book = book;
            _parent = parent;

            if (book.BookId.Equals(int.MinValue)) 
            {
                _bookAuthors = DbUtils.GetAllActiveAuthors();
                _bookGenres = DbUtils.GetAllActiveBookGenres();
                _bookPublishers = DbUtils.GetAllActivePublishers();
                _currentBooksAuthors = new List<Author>();
            } 
            else
            {
                _bookAuthors = DbUtils.GetAllAuthors();
                _bookGenres = DbUtils.GetAllBookGenres();
                _bookPublishers = DbUtils.GetAllPublishers();
                _currentBooksAuthors = DbUtils.GetBookAuthorsOf(book);
            }

            _bookTitleBoxText = book.Title;
            _bookGenreSelectedItem = string.Empty;
            _bookPublisherSelectedItem = string.Empty;
            _bookStockBoxText = book.Stock.ToString();
            _bookPublishYearBoxText = book.PublishYear.ToString();

            AllAuthorsLastNames = new List<string>();
            AllBookGenresNames = new List<string>();
            AllBookPublishersNames = new List<string>();

            _uncheckedAuthors = new ObservableCollection<string>();
            _checkedAuthors = new ObservableCollection<string>();

            foreach (Models.Author author in _bookAuthors)
            {
                if (_currentBooksAuthors.Find(target => target.AuthorId == author.AuthorId) != null)
                {
                    _checkedAuthors.Add(author.LastName);
                }
                else
                {
                    _uncheckedAuthors.Add(author.LastName);
                }

                AllAuthorsLastNames.Add(author.LastName);
            }

            foreach (Models.BookType genre in _bookGenres)
            {

                if (genre.BookTypeId == book.BookTypeId)
                {
                    _bookGenreSelectedItem = genre.Name;
                }

                AllBookGenresNames.Add(genre.Name);
            }

            foreach (Models.Publisher publisher in _bookPublishers)
            {

                if (publisher.PublisherId == book.PublisherId)
                {
                    _bookPublisherSelectedItem = publisher.Name;
                }

                AllBookPublishersNames.Add(publisher.Name);
            }

            _canClickSaveButton = !string.IsNullOrEmpty(book.Title);
        }

        private void UpdateCanClickSaveButton()
        {
            CanClickSaveButton = !string.IsNullOrEmpty(BookTitleBoxText)
                && !CheckedAuthors.IsNullOrEmpty()
                && !string.IsNullOrEmpty(BookGenreSelectedItem)
                && !string.IsNullOrEmpty(BookPublisherSelectedItem)
                && !string.IsNullOrEmpty(BookStockBoxText)
                && !string.IsNullOrEmpty(BookPublishYearBoxText)
                ;
        }
    }
}
