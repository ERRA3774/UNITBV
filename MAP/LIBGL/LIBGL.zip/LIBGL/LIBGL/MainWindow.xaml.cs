﻿using System.Reflection.PortableExecutable;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

using LIBGL.Utils;
using LIBGL.Pages;

namespace LIBGL
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void BG_PreviewMouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            Tg_Btn.IsChecked = false;
        }



        private void ButtonHome_MouseEnter(object sender, MouseEventArgs e)
        {
            if (Tg_Btn.IsChecked == true)
            {
                return;
            }

            Popup.PlacementTarget = ButtonHome;
            Popup.Placement = PlacementMode.Right;
            Popup.IsOpen = true;
            Header.PopupText.Text = Consts.HOME_PAGE_TITLE;
        }

        private void ButtonHome_MouseLeave(object sender, MouseEventArgs e)
        {
            Popup.Visibility = Visibility.Collapsed;
            Popup.IsOpen = false;
        }



        private void ButtonUser_MouseEnter(object sender, MouseEventArgs e)
        {
            if (Tg_Btn.IsChecked == true)
            {
                return;
            }

            Popup.PlacementTarget = ButtonUser;
            Popup.Placement = PlacementMode.Right;
            Popup.IsOpen = true;
            Header.PopupText.Text = Consts.USERS_PAGE_TITLE;
        }

        private void ButtonUser_MouseLeave(object sender, MouseEventArgs e)
        {
            Popup.Visibility = Visibility.Collapsed;
            Popup.IsOpen = false;
        }



        private void ButtonDashboard_MouseEnter(object sender, MouseEventArgs e)
        {
            if (Tg_Btn.IsChecked == true)
            {
                return;
            }

            Popup.PlacementTarget = ButtonDashboard;
            Popup.Placement = PlacementMode.Right;
            Popup.IsOpen = true;
            Header.PopupText.Text = Consts.DASHBOARD_PAGE_TITLE;
        }

        private void ButtonDashboard_MouseLeave(object sender, MouseEventArgs e)
        {
            Popup.Visibility = Visibility.Collapsed;
            Popup.IsOpen = false;
        }



        private void ButtonPublishers_MouseEnter(object sender, MouseEventArgs e)
        {
            if (Tg_Btn.IsChecked == true)
            {
                return;
            }

            Popup.PlacementTarget = ButtonPublishers;
            Popup.Placement = PlacementMode.Right;
            Popup.IsOpen = true;
            Header.PopupText.Text = Consts.PUBLISHERS_PAGE_TITLE;

        }

        private void ButtonPublishers_MouseLeave(object sender, MouseEventArgs e)
        {
            Popup.Visibility = Visibility.Collapsed;
            Popup.IsOpen = false;
        }



        private void ButtonAuthors_MouseEnter(object sender, MouseEventArgs e)
        {
            if (Tg_Btn.IsChecked == true)
            {
                return;
            }

            Popup.PlacementTarget = ButtonAuthors;
            Popup.Placement = PlacementMode.Right;
            Popup.IsOpen = true;
            Header.PopupText.Text = Consts.AUTHORS_PAGE_TITLE;
        }

        private void ButtonAuthors_MouseLeave(object sender, MouseEventArgs e)
        {
            Popup.Visibility = Visibility.Collapsed;
            Popup.IsOpen = false;
        }



        private void ButtonGenres_MouseEnter(object sender, MouseEventArgs e)
        {
            if (Tg_Btn.IsChecked == true)
            {
                return;
            }

            Popup.PlacementTarget = ButtonGenres;
            Popup.Placement = PlacementMode.Right;
            Popup.IsOpen = true;
            Header.PopupText.Text = Consts.GENRES_PAGE_TITLE;
        }

        private void ButtonGenres_MouseLeave(object sender, MouseEventArgs e)
        {
            Popup.Visibility = Visibility.Collapsed;
            Popup.IsOpen = false;
        }



        private void ButtonBooks_MouseEnter(object sender, MouseEventArgs e)
        {
            if (Tg_Btn.IsChecked == true)
            {
                return;
            }

            Popup.PlacementTarget = ButtonBooks;
            Popup.Placement = PlacementMode.Right;
            Popup.IsOpen = true;
            Header.PopupText.Text = Consts.BOOKS_PAGE_TITLE;
        }

        private void ButtonBooks_MouseLeave(object sender, MouseEventArgs e)
        {
            Popup.Visibility = Visibility.Collapsed;
            Popup.IsOpen = false;
        }



        private void ButtonBorrowedBooks_MouseEnter(object sender, MouseEventArgs e)
        {
            if (Tg_Btn.IsChecked == true)
            {
                return;
            }

            Popup.PlacementTarget = ButtonBorrowedBooks;
            Popup.Placement = PlacementMode.Right;
            Popup.IsOpen = true;
            Header.PopupText.Text = Consts.BORROWED_BOOKS_PAGE_TITLE;
        }

        private void ButtonBorrowedBooks_MouseLeave(object sender, MouseEventArgs e)
        {
            Popup.Visibility = Visibility.Collapsed;
            Popup.IsOpen = false;
        }



        private void ButtonSecurity_MouseEnter(object sender, MouseEventArgs e)
        {
            if (Tg_Btn.IsChecked == true)
            {
                return;
            }

            Popup.PlacementTarget = ButtonSecurity;
            Popup.Placement = PlacementMode.Right;
            Popup.IsOpen = true;
            Header.PopupText.Text = Consts.COMING_SOON_TEXT;
        }

        private void ButtonSecurity_MouseLeave(object sender, MouseEventArgs e)
        {
            Popup.Visibility = Visibility.Collapsed;
            Popup.IsOpen = false;
        }



        private void ButtonSettings_MouseEnter(object sender, MouseEventArgs e)
        {
            if (Tg_Btn.IsChecked == true)
            {
                return;
            }

            Popup.PlacementTarget = ButtonSettings;
            Popup.Placement = PlacementMode.Right;
            Popup.IsOpen = true;
            Header.PopupText.Text = Consts.COMING_SOON_TEXT;
        }

        private void ButtonSettings_MouseLeave(object sender, MouseEventArgs e)
        {
            Popup.Visibility = Visibility.Collapsed;
            Popup.IsOpen = false;
        }



        private void ButtonClose_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }

        private void ButtonRestore_Click(object sender, RoutedEventArgs e)
        {
            WindowState = WindowState == WindowState.Normal ? WindowState.Maximized : WindowState.Normal;
        }

        private void ButtonMinimize_Click(object sender, RoutedEventArgs e)
        {
            WindowState = WindowState.Minimized;
        }


        private void ButtonHome_Click(object sender, RoutedEventArgs e)
        {
            fContainer.Navigate(new HomePage());
        }

        private void ButtonUser_Click(object sender, RoutedEventArgs e)
        {
            fContainer.Navigate(new UsersPage());
        }

        private void ButtonDashboard_Click(object sender, RoutedEventArgs e)
        {
            fContainer.Navigate(new DashboardPage());
        }

        private void ButtonPublishers_Click(object sender, RoutedEventArgs e)
        {
            fContainer.Navigate(new PublishersPage());
        }

        private void ButtonAuthors_Click(object sender, RoutedEventArgs e)
        {
            fContainer.Navigate(new AuthorsPage());
        }

        private void ButtonGenres_Click(object sender, RoutedEventArgs e)
        {
            fContainer.Navigate(new BookGenresPage());
        }

        private void ButtonBooks_Click(object sender, RoutedEventArgs e)
        {
            fContainer.Navigate(new BooksPage());
        }

        private void ButtonBorrowedBooks_Click(object sender, RoutedEventArgs e)
        {
            fContainer.Navigate(new BorrowedBooksPage());
        }

    }
}