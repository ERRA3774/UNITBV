﻿using LIBGL.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace LIBGL.Pages
{
    /// <summary>
    /// Interaction logic for UsersPage.xaml
    /// </summary>
    public partial class UsersPage : Page
    {
        private readonly UsersPageViewModel _viewModel;
        public UsersPage()
        {
            InitializeComponent();
            _viewModel = new UsersPageViewModel();
            DataContext = _viewModel;
        }

        private void DataGridUsers_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            if (sender is not DataGrid grid || grid.SelectedItem is not Models.User || grid.SelectedItems.Count != 1)
            {
                return;
            }

            Models.User? selectedUser = grid.SelectedItem as Models.User;
            DataGridUsers.UnselectAll();
            NavigationService.Navigate(ChildPage(selectedUser));
        }

        private void ButtonPlus_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(ChildPage(new Models.User()));
        }

        private UserDetailPage ChildPage(Models.User? user)
        {
            user ??= new Models.User();

            UserDetailsViewModel childViewModel = new UserDetailsViewModel(_viewModel, user);
            UserDetailPage? childPage = new UserDetailPage(childViewModel);
            return childPage;
        }

        private void FilterBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (sender is not TextBox filterBox)
            {
                return;
            }

            _viewModel.FilterUsers(filterBox.Text);
        }

        private void DataGridUsers_AutoGeneratingColumn(object sender, DataGridAutoGeneratingColumnEventArgs e)
        {
            if (e.PropertyName == "UserId")
            {
                e.Cancel = true;
            }

            if (e.PropertyName == "Active")
            {
                e.Cancel = true;
            }

            if (e.PropertyName == "Phone")
            {
                e.Column.Width = 120;
            }
        }

    }
}
