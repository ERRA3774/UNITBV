﻿using LIBGL.Databases;
using LIBGL.Utils;
using LIBGL.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace LIBGL.Pages
{
    public partial class BorrowedBookDetailPage : Page
    {
        private readonly Models.UserBook _userBook;
        public BorrowedBookDetailsViewModel BorrowedBookDetailsViewModel { get; }

        public BorrowedBookDetailPage(BorrowedBookDetailsViewModel borrowedBookDetailsViewModel)
        {
            InitializeComponent();
            BorrowedBookDetailsViewModel = borrowedBookDetailsViewModel;
            DataContext = BorrowedBookDetailsViewModel;

            _userBook = BorrowedBookDetailsViewModel.UserBook;

            if (_userBook.Id.Equals(int.MinValue))
            {
                ButtonDelete.Visibility = Visibility.Hidden;
                ButtonSave.Content = Consts.ADD_TEXT;
                DetailsHeader.Text = Consts.USER_BOOK_ADD_TEXT;
            }
        }

        private void ButtonSave_Click(object sender, RoutedEventArgs e)
        {
            if (sender is not Button button)
            {
                return;
            }

            Models.UserBook userBook = new Models.UserBook
            {
                
            };

            if (_userBook.Id.Equals(int.MinValue))
            {
                //DbUtils.InsertUserBook(userBook);
            }
            else
            {
                userBook.Id = _userBook.Id;
                userBook.Active = _userBook.Active;
                //DbUtils.UpdateUserBook(userBook);
            }

            NavigationService.Navigate(new BorrowedBooksPage());
        }

        private void ButtonCancel_Click(object sender, RoutedEventArgs e)
        {
            if (sender is not Button)
            {
                return;
            }

            NavigationService.Navigate(new BorrowedBooksPage());
        }

        private void ButtonDelete_Click(object sender, RoutedEventArgs e)
        {
            if (sender is not Button button)
            {
                return;
            }

            //DbUtils.DeleteUserBook(_userBook.Id);

            NavigationService.Navigate(new BorrowedBooksPage());
        }

        private void PrimaryInputLimit_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            if (sender is not TextBox textBox)
            {
                return;
            }

            if (textBox.Text.Length >= Consts.TEXTBOX_PRIMARY_LIMIT)
            {
                e.Handled = true;
            }
        }
    }
}
