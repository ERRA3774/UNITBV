#include "GraphGUI.h"

GraphGUI::GraphGUI() {
	if (!m_textFont.loadFromFile(C::FONT_PATH)) {
		std::cout << "GraphGUI >>> Could not load font from file." << std::endl;
	}

	sf::Vector2f boxPosition(1500, 10);
	m_box.setSize(sf::Vector2f(410, 1060));
	m_box.setOutlineThickness(5.0f);
	m_box.setFillColor(sf::Color::Black);
	m_box.setOutlineColor(sf::Color::White);
	m_box.setPosition(boxPosition.x, boxPosition.y);

	m_modeName.setFont(m_textFont);
	m_modeName.setString(C::MODE_NAMES[0]);
	m_modeName.setFillColor(sf::Color::White);
	m_modeName.setCharacterSize(22);
	float yOffset = m_modeName.getLocalBounds().height;
	m_modeName.setPosition(boxPosition.x + 10, m_box.getPosition().y + yOffset);

	m_traversalName.setFont(m_textFont);
	m_traversalName.setString(C::TRAVERSAL_NAMES[0]);
	m_traversalName.setFillColor(sf::Color::White);
	m_traversalName.setCharacterSize(22);
	yOffset += m_traversalName.getLocalBounds().height;
	m_traversalName.setPosition(boxPosition.x + 10, 2 * m_box.getPosition().y + yOffset);

	m_edgeWeight.setFont(m_textFont);
	m_edgeWeight.setString(std::to_string(C::UNITIALIZED_WEIGHT));
	m_edgeWeight.setFillColor(sf::Color::White);
	m_edgeWeight.setCharacterSize(22);
	yOffset += m_edgeWeight.getLocalBounds().height;
	m_edgeWeight.setPosition(boxPosition.x + 10, 3 * m_box.getPosition().y + yOffset);

	m_commands.setFont(m_textFont);
	m_commands.setCharacterSize(22);
	m_commands.setString(
		R"(
Commands:
ESC - Default Mode
C - Create Mode
Q - Connect Mode
T - Traverse Mode
M - Move Mode
A - Print Data 
R - Reset Everything
I - Increment weight
K - Decrement weight
LClick - Add Node
RClick - Erase Node 

Traversals:
1 - ShortPath
2 - Prim
3 - Kruskal
4 - Dijkstra
5 - BellmanFord
6 - FloydWashall
)");
	m_commands.setPosition(boxPosition.x + 10, 4 * m_box.getPosition().y + yOffset);
}

void GraphGUI::Render(sf::RenderWindow& window, const int mode, const int traversal, const float edgeWeight) {
	m_modeName.setString("Mode: " + C::MODE_NAMES[mode]);
	m_traversalName.setString("Traversal: " + C::TRAVERSAL_NAMES[traversal]);
	m_edgeWeight.setString("Weight: " + std::to_string(edgeWeight));

	window.draw(m_box);
	window.draw(m_modeName);
	window.draw(m_traversalName);
	window.draw(m_edgeWeight);
	window.draw(m_commands);
}