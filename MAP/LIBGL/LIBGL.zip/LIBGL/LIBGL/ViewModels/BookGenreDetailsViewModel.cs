﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LIBGL.ViewModels
{
    public class BookGenreDetailsViewModel : ViewModelBase
    {
        private readonly BookGenresPageViewModel _parent;

        private Models.BookType _bookGenre;
        public Models.BookType BookGenre
        {
            get
            {
                return _bookGenre;
            }
            set
            {
                _bookGenre = value;
                OnPropertyChanged(nameof(BookGenre));
            }
        }

        private string _bookGenreNameBoxText;
        public string BookGenreNameBoxText
        {
            get
            {
                return _bookGenreNameBoxText;
            }
            set
            {
                _bookGenreNameBoxText = value;
                OnPropertyChanged(nameof(BookGenreNameBoxText));
                UpdateCanClickSaveButton();
            }
        }

        private bool _canClickSaveButton;
        public bool CanClickSaveButton
        {
            get { return _canClickSaveButton; }
            set
            {
                _canClickSaveButton = value;
                OnPropertyChanged(nameof(CanClickSaveButton));
            }
        }

        private void UpdateCanClickSaveButton()
        {
            CanClickSaveButton = !string.IsNullOrEmpty(BookGenreNameBoxText);
        }

        public BookGenreDetailsViewModel(BookGenresPageViewModel parent, Models.BookType bookGenre)
        {
            _bookGenre = bookGenre;
            _parent = parent;
            _bookGenreNameBoxText = bookGenre.Name;
            _canClickSaveButton = !string.IsNullOrEmpty(bookGenre.Name);
        }
    }
}
