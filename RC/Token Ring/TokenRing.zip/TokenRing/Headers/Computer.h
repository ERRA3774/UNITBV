#pragma once

#include <fstream>
#include <iostream>

#include "../Headers/Token.h"

class Computer {
public:

	Computer();

	std::string GetIp() const;

	std::string GetMessage() const;

	void FetchSecretMessageFromFile(const std::string& path);

private:

	std::string GenerateRandomIp();

private:
	std::string _ip;
	std::string _message;
	bool _hasToken;

};

