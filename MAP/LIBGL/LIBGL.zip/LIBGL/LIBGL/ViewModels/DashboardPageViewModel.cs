﻿using LIBGL.Databases;
using LIBGL.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LIBGL.ViewModels
{
    public class DashboardPageViewModel : ViewModelBase
    {
        private List<Models.Author> _authors;
        public List<Models.Author> Authors
        {
            get => _authors;
            set
            {
                _authors = value;
                OnPropertyChanged(nameof(Authors));
            }
        }



        private List<Models.AuthorBook> _authorBooks;
        public List<Models.AuthorBook> AuthorBooks
        {
            get => _authorBooks;
            set
            {
                _authorBooks = value;
                OnPropertyChanged(nameof(AuthorBooks));
            }
        }



        private List<Models.Book> _books;
        public List<Models.Book> Books
        {
            get => _books;
            set
            {
                _books = value;
                OnPropertyChanged(nameof(Books));
            }
        }



        private List<Models.BookType> _bookTypes;
        public List<Models.BookType> BookTypes
        {
            get => _bookTypes;
            set
            {
                _bookTypes = value;
                OnPropertyChanged(nameof(BookTypes));
            }
        }



        private List<Models.Publisher> _publishers;
        public List<Models.Publisher> Publishers
        {
            get => _publishers;
            set
            {
                _publishers = value;
                OnPropertyChanged(nameof(Publishers));
            }
        }

        private List<Models.User> _users;
        public List<Models.User> Users
        {
            get => _users;
            set
            {
                _users = value;
                OnPropertyChanged(nameof(Users));
            }
        }

        private List<Models.UserBook> _userBooks;
        public List<Models.UserBook> UserBooks
        {
            get => _userBooks;
            set
            {
                _userBooks = value;
                OnPropertyChanged(nameof(UserBooks));
            }
        }

        public DashboardPageViewModel()
        {
            _authors = DbUtils.GetAllAuthors();
            _authorBooks = DbUtils.GetAllAuthorBooks();
            _books = DbUtils.GetAllBooks();
            _bookTypes = DbUtils.GetAllBookGenres();
            _publishers = DbUtils.GetAllPublishers();
            _users = DbUtils.GetAllUsers();
            _userBooks = DbUtils.GetAllUserBooks();
        }
    }
}
