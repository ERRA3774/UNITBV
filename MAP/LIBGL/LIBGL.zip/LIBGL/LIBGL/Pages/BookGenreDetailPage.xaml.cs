﻿using LIBGL.Databases;
using LIBGL.Utils;
using LIBGL.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace LIBGL.Pages
{
    /// <summary>
    /// Interaction logic for BookGenreDetailPage.xaml
    /// </summary>
    public partial class BookGenreDetailPage : Page
    {
        private readonly Models.BookType _bookGenre;
        public BookGenreDetailsViewModel BookGenreDetailsViewModel { get; }

        public BookGenreDetailPage(BookGenreDetailsViewModel bookGenreDetailsViewModel)
        {
            InitializeComponent();
            BookGenreDetailsViewModel = bookGenreDetailsViewModel;
            DataContext = BookGenreDetailsViewModel;

            _bookGenre = bookGenreDetailsViewModel.BookGenre;

            if (_bookGenre.BookTypeId.Equals(int.MinValue))
            {
                ButtonDelete.Visibility = Visibility.Hidden;
                ButtonSave.Content = Consts.ADD_TEXT;
                BookGenreDetailsHeader.Text = Consts.BOOK_TYPE_ADD_TEXT;
            }
        }

        private void ButtonSave_Click(object sender, RoutedEventArgs e)
        {
            if (sender is not Button button)
            {
                return;
            }

            Models.BookType bookGenre = new Models.BookType
            {
                Name = TextBoxBookGenreName.Text,
            };

            if (_bookGenre.BookTypeId.Equals(int.MinValue))
            {
                DbUtils.InsertBookGenre(bookGenre);
            }
            else
            {
                bookGenre.BookTypeId = _bookGenre.BookTypeId;
                bookGenre.Active = _bookGenre.Active;
                DbUtils.UpdateBookGenre(bookGenre);
            }

            NavigationService.Navigate(new BookGenresPage());
        }

        private void ButtonCancel_Click(object sender, RoutedEventArgs e)
        {
            if (sender is not Button)
            {
                return;
            }

            NavigationService.Navigate(new BookGenresPage());
        }

        private void ButtonDelete_Click(object sender, RoutedEventArgs e)
        {
            if (sender is not Button button)
            {
                return;
            }

            DbUtils.DeleteBookGenre(_bookGenre.BookTypeId);

            NavigationService.Navigate(new BookGenresPage());
        }

        private void PrimaryInputLimit_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            if (sender is not TextBox textBox)
            {
                return;
            }

            if (textBox.Text.Length >= Consts.TEXTBOX_PRIMARY_LIMIT)
            {
                e.Handled = true;
            }
        }
    }
}
