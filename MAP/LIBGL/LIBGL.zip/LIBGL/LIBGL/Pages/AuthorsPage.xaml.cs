﻿using LIBGL.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace LIBGL.Pages
{
    public partial class AuthorsPage : Page
    {
        private readonly AuthorsPageViewModel _viewModel;
        public AuthorsPage()
        {
            InitializeComponent();
            _viewModel = new AuthorsPageViewModel();
            DataContext = _viewModel;
        }

        private void DataGridAuthors_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            if (sender is not DataGrid grid || grid.SelectedItem is not Models.Author || grid.SelectedItems.Count != 1)
            {
                return;
            }

            Models.Author? selectedAuthor = grid.SelectedItem as Models.Author;
            DataGridAuthors.UnselectAll();
            NavigationService.Navigate(ChildPage(selectedAuthor));
        }

        private void ButtonPlus_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(ChildPage(new Models.Author()));
        }

        private AuthorDetailPage ChildPage(Models.Author? author)
        {
            author ??= new Models.Author();

            AuthorDetailsViewModel childViewModel = new AuthorDetailsViewModel(_viewModel, author);
            AuthorDetailPage? childPage = new AuthorDetailPage(childViewModel);
            return childPage;
        }

        private void FilterBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (sender is not TextBox filterBox)
            {
                return;
            }

            _viewModel.FilterAuthors(filterBox.Text);
        }

        private void DataGridAuthors_AutoGeneratingColumn(object sender, DataGridAutoGeneratingColumnEventArgs e)
        {
            if (e.PropertyName == "AuthorId")
            {
                e.Cancel = true;
            }

            if (e.PropertyName == "Active")
            {
                e.Cancel = true;
            }

            if (e.PropertyName == "BirthDate")
            {
                e.Column.Width = 120;
            }
        }

    }
}
