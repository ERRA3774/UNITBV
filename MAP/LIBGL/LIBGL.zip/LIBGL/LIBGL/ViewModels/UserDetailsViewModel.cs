﻿using LIBGL.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace LIBGL.ViewModels
{
    public class UserDetailsViewModel : ViewModelBase
    {
        private readonly UsersPageViewModel _parent;

        private Models.User _user;
        public Models.User User
        {
            get
            {
                return _user;
            }
            set
            {
                _user = value;
                OnPropertyChanged(nameof(User));
            }
        }

        private string _firstNameBoxText;
        public string FirstNameBoxText
        {
            get
            {
                return _firstNameBoxText;
            }
            set
            {
                _firstNameBoxText = value;
                OnPropertyChanged(nameof(FirstNameBoxText));
                UpdateCanClickSaveButton();
            }
        }

        private string _lastNameBoxText;
        public string LastNameBoxText
        {
            get
            {
                return _lastNameBoxText;
            }
            set
            {
                _lastNameBoxText = value;
                OnPropertyChanged(nameof(LastNameBoxText));
                UpdateCanClickSaveButton();
            }
        }

        private string _emailBoxText;
        public string EmailBoxText
        {
            get
            {
                return _emailBoxText;
            }
            set
            {
                _emailBoxText = value;
                OnPropertyChanged(nameof(EmailBoxText));
                UpdateCanClickSaveButton();
            }
        }

        private string _phoneBoxText;
        public string PhoneBoxText
        {
            get
            {
                return _phoneBoxText;
            }
            set
            {
                _phoneBoxText = value;
                OnPropertyChanged(nameof(PhoneBoxText));
                UpdateCanClickSaveButton();
            }
        }

        private bool _canClickSaveButton;
        public bool CanClickSaveButton
        {
            get { return _canClickSaveButton; }
            set
            {
                _canClickSaveButton = value;
                OnPropertyChanged(nameof(CanClickSaveButton));
            }
        }

        public UserDetailsViewModel(UsersPageViewModel parent, Models.User user)
        {
            _user = user;
            _parent = parent;
            _firstNameBoxText = user.FirstName;
            _lastNameBoxText = user.LastName;
            _emailBoxText = user.Email;
            _phoneBoxText = user.Phone;
            _canClickSaveButton = !string.IsNullOrEmpty(user.FirstName) 
                && !string.IsNullOrEmpty(user.LastName)
                && !string.IsNullOrEmpty(user.Email)
                && !string.IsNullOrEmpty(user.Phone);
        }
        private void UpdateCanClickSaveButton()
        {
            CanClickSaveButton = !string.IsNullOrEmpty(FirstNameBoxText)
                && !string.IsNullOrEmpty(LastNameBoxText)
                && ValidEmail(EmailBoxText)
                && ValidPhone(PhoneBoxText);
        }

        private bool ValidEmail(string input)
        {
            string pattern = "^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}$";

            return !string.IsNullOrEmpty(input) && Regex.IsMatch(input, pattern);
        }

        private bool ValidPhone(string input)
        {
            string pattern = "^\\+?(\\d[\\d-. ]+)?(\\([\\d-. ]+\\))?[\\d-. ]+\\d$";

            return !string.IsNullOrEmpty(input) && Regex.IsMatch(input, pattern);
        }
    }
}
