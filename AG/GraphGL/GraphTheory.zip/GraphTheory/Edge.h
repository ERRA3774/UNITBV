#pragma once

#include "Node.h"

class Edge {
public:
	Edge();
	Edge(Node start, Node other, bool directed, float weight);
	Node Start() const;
	Node End() const;
	bool Directed() const;
	float Weight() const;

	void SetStart(Node& node);
	void SetEnd(Node& node);
	void SetWeight(float& weight);
	void SetDirected(bool& directed);

	friend bool operator==(const Edge& lhs, const Edge& rhs);

private:
	Node m_start;
	Node m_other;

	bool m_directed;
	
	float m_weight;
};
