﻿using System.Windows;
using System.Windows.Controls;

using XOGL.Views;
using XOGL.Utils;

namespace XOGL
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private UserControl _currentView;

        public MainWindow()
        {
            InitializeComponent();
            InitializeMenuAbout();
        }

        private void MenuItem_NewGame(object sender, RoutedEventArgs e)
        {
            if (_currentView != null)
            {
                GrdView.Children.Remove(_currentView);
            }

            GrdView.Children.Remove(TbStartMessage);

            _currentView = new UserSetupView();
            GrdView.Children.Add(_currentView);
        }

        private void MenuItem_Exit(object sender, RoutedEventArgs e)
        {
            this.Close();
        }

        private void InitializeMenuAbout()
        {
            MenuAbout.Items.Add(XOConstants.DEV_LAST_NAME);
            MenuAbout.Items.Add(XOConstants.DEV_FIRST_NAME);
            MenuAbout.Items.Add(XOConstants.DEV_EMAIL_ADDRESS);
            MenuAbout.Items.Add(XOConstants.SHORT_DESCRIPTION);
            MenuAbout.Items.Add(DateTime.Now.ToString("dddd, MMM dd yyyy, hh:mm:ss"));
        }
    }
}