#include "EdgeRenderer.h"

EdgeRenderer::EdgeRenderer(Graph& graph) :
	m_graph(graph) {
	if (!m_font.loadFromFile(C::FONT_PATH)) {
		std::cout << "EdgeRenderer >>> Could not load font from path." << std::endl;
	}
	m_weight.setFont(m_font);
}

void EdgeRenderer::Render(sf::RenderWindow& window, const Edge& edge, sf::Color lineColor) {
	float startX = static_cast<float>(edge.Start().X);
	float startY = static_cast<float>(edge.Start().Y);
	float endX = static_cast<float>(edge.End().X);
	float endY = static_cast<float>(edge.End().Y);

	float dx = endX - startX;
	float dy = endY - startY;

	float angle = std::atan2(dy, dx) * (C::DEG_180 / static_cast<float>(C::PI));
	float dist = std::sqrt(dx * dx + dy * dy);

	m_line.setSize(sf::Vector2f(dist, C::LINE_THICKNESS));
	m_line.setRotation(angle);
	m_line.setPosition(sf::Vector2f(startX, startY));
	m_line.setFillColor(lineColor);

	m_arrowhead.setPointCount(3);
	m_arrowhead.setRadius(7.0f);
	m_arrowhead.setOrigin(7.0f, 7.0f);
	m_arrowhead.setPosition(endX, endY);
	m_arrowhead.setFillColor(sf::Color::White);

	m_weight.setString(std::to_string(static_cast<int>(edge.Weight())));
	m_weight.setPosition((startX + endX) / 2, (startY + endY) / 2);
	m_weight.setFillColor(sf::Color::Red);

	window.draw(m_line);
	window.draw(m_arrowhead);
	window.draw(m_weight);
}