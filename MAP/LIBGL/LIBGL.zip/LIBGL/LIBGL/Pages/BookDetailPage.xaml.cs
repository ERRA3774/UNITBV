﻿using LIBGL.Databases;
using LIBGL.Models;
using LIBGL.Utils;
using LIBGL.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace LIBGL.Pages
{
    public partial class BookDetailPage : Page
    {
        private readonly Models.Book _book;
        public BookDetailsViewModel BookDetailsViewModel { get; }

        public BookDetailPage(BookDetailsViewModel bookDetailsViewModel)
        {
            InitializeComponent();
            BookDetailsViewModel = bookDetailsViewModel;
            DataContext = BookDetailsViewModel;

            _book = bookDetailsViewModel.Book;

            if (_book.BookId.Equals(int.MinValue))
            {
                ButtonDelete.Visibility = Visibility.Hidden;
                ButtonSave.Content = Consts.ADD_TEXT;
                BookDetailsHeader.Text = Consts.BOOK_ADD_TEXT;
            }
        }

        private void ButtonSave_Click(object sender, RoutedEventArgs e)
        {
            if (sender is not Button)
            {
                return;
            }

            Models.Book book = new Models.Book
            {
                BookId = _book.BookId,
                Title = TextBoxBookTitle.Text,
                BookTypeId = BookTypeIdFrom(BookDetailsViewModel.BookGenreSelectedItem),
                PublisherId = PublisherIdFrom(BookDetailsViewModel.BookPublisherSelectedItem),
                Stock = Convert.ToInt32(BookDetailsViewModel.BookStockBoxText),
                PublishYear = Convert.ToInt32(BookDetailsViewModel.BookPublishYearBoxText),
                Active = _book.Active,
            };

            if (book.BookId.Equals(int.MinValue))
            {
                book.BookId = DbUtils.InsertBook(book);
            }
            else
            {
                DbUtils.UpdateBook(book);
            }

            List<Models.Author> currentBooksAuthors = BookDetailsViewModel.CurrentBooksAuthors;
            List<Models.AuthorBook> authorBooks = new List<Models.AuthorBook>();
            int orderValue = 1;

            foreach (Models.Author author in currentBooksAuthors)
            {
                Models.AuthorBook authorBook = new Models.AuthorBook
                {
                    AuthorId = author.AuthorId,
                    BookId = book.BookId,
                    NumberInList = orderValue,
                };

                authorBooks.Add(authorBook);
                orderValue++;
            }

            foreach (Models.AuthorBook authorBook in authorBooks)
            {
                DbUtils.InsertAuthorBook(authorBook);
            }

            NavigationService.Navigate(new BooksPage());
        }

        private void ButtonCancel_Click(object sender, RoutedEventArgs e)
        {
            if (sender is not Button)
            {
                return;
            }

            NavigationService.Navigate(new BooksPage());
        }

        private void ButtonDelete_Click(object sender, RoutedEventArgs e)
        {
            if (sender is not Button)
            {
                return;
            }

            DbUtils.DeleteBook(_book.BookId);

            NavigationService.Navigate(new BooksPage());
        }

        private void CheckBoxCheckAuthor_Click(object sender, RoutedEventArgs e)
        {
            if (sender is not CheckBox checkBox)
            {
                return;
            }

            if (checkBox.Content is null)
            {
                return;
            }

            string authorName = checkBox.Content as string ?? "N/A";

            BookDetailsViewModel.CheckedAuthors.Add(authorName);
            BookDetailsViewModel.UncheckedAuthors.Remove(authorName);
            BookDetailsViewModel.CurrentBooksAuthors.Add(AuthorFindBy(authorName));
        }

        private void CheckBoxUncheckAuthor_Click(object sender, RoutedEventArgs e)
        {
            if (sender is not CheckBox checkBox)
            {
                return;
            } 

            if (checkBox.Content is null)
            {
                return;
            }

            string authorName = checkBox.Content as string ?? "N/A";

            BookDetailsViewModel.UncheckedAuthors.Add(authorName);
            BookDetailsViewModel.CheckedAuthors.Remove(authorName);
            BookDetailsViewModel.CurrentBooksAuthors.Remove(AuthorFindBy(authorName));
        }

        private void PrimaryInputLimit_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            if (sender is not TextBox textBox)
            {
                return;
            }

            if (textBox.Text.Length >= Consts.TEXTBOX_PRIMARY_LIMIT)
            {
                e.Handled = true;
            }
        }

        private void SecondaryInputLimit_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            if (sender is not TextBox textBox)
            {
                return;
            }

            if (textBox.Text.Length >= Consts.TEXTBOX_SECONDARY_LIMIT)
            {
                e.Handled = true;
            }
        }

        private void TertiaryInputLimit_PreviewTextInput(object sender, TextCompositionEventArgs e)
        {
            if (sender is not TextBox textBox)
            {
                return;
            }

            if (textBox.Text.Length >= Consts.TEXTBOX_TERTIARY_LIMIT)
            {
                e.Handled = true;
            }
        }

        private int BookTypeIdFrom(string genreName)
        {
            foreach (Models.BookType bookType in BookDetailsViewModel.BookGenres)
            {
                if (bookType.Name == genreName)
                {
                    return bookType.BookTypeId;
                }
            }

            return -1;
        }

        private int PublisherIdFrom(string publisherName)
        {
            foreach (Models.Publisher publisher in BookDetailsViewModel.BookPublishers)
            {
                if (publisher.Name == publisherName)
                {
                    return publisher.PublisherId;
                }
            }

            return -1;
        }

        private Author AuthorFindBy(string authorName)
        {
            foreach (Models.Author author in BookDetailsViewModel.BookAuthors)
            {
                if (author.LastName == authorName)
                {
                    return author;
                }
            }

            return new Author();
        }
    }
}
