#pragma once
#include "Constants.h"

class Node {
	using C = Constants;

public:
	Node();
	Node(const unsigned int x, const unsigned int y, const int val, bool selected);

	friend bool operator==(const Node& lhs, const Node& rhs);
	friend bool operator!=(const Node& lhs, const Node& rhs);

public:
	unsigned int X;
	unsigned int Y;
	int VALUE;
	bool SELECTED;
};