#include "GraphApp.h"

GraphApp::GraphApp(Graph& graph) :
	m_graph(graph),
	m_nodeRenderer(graph),
	m_edgeRenderer(graph),
	m_currentMode(AppMode::Default),
	m_currentTraversal(Traversal::None),
	m_window(sf::VideoMode(C::WINDOW_WIDTH, C::WINDOW_HEIGHT), C::WINDOW_TITLE, sf::Style::Close) {

}

void GraphApp::Run() {
	m_window.setFramerateLimit(60);
	
	while (m_window.isOpen()) {
		// Handle events
		sf::Event windowEvent;
		while (m_window.pollEvent(windowEvent)) {

			switch (windowEvent.type)
			{
			case sf::Event::Closed:
				m_window.close();
				break;

			case sf::Event::LostFocus:
				std::cout << "Window Lost Focus" << std::endl;
				break;

			case sf::Event::KeyPressed:
				std::cout << "Window Key Pressed" << std::endl;
				_OnKeyPressed(windowEvent);
				break;

			case sf::Event::MouseMoved:
				_OnMouseMoved();
				break;

			case sf::Event::MouseButtonPressed:
				_OnMouseButtonPressed(windowEvent);
				break;

			case sf::Event::MouseButtonReleased:
				_OnMouseButtonReleased(windowEvent);
				break;

			default:
				std::cout << "WindowEvent >>> default" << std::endl;
				break;
			}

		}

		// Update Logic

		// Clear the window
		m_window.clear();

		// Draw everything

		for (const auto& node : m_graph.Nodes()) {
			m_nodeRenderer.Render(m_window, node);
		}

		for (const auto& edge : m_graph.Edges()) {
			m_edgeRenderer.Render(m_window, edge);
		}

		for (const auto& edge : m_graph.Traverse(static_cast<int>(m_currentTraversal))) {
			m_edgeRenderer.Render(m_window, edge, sf::Color::Red);
		}

		m_gui.Render(m_window, static_cast<int>(m_currentMode), static_cast<int>(m_currentTraversal), m_graph.CURRENT_WEIGHT);

		// End of frame
		m_window.display();
	}
}

void GraphApp::_OnKeyPressed(sf::Event& keyEvent) {
	switch (keyEvent.key.code) {
	case sf::Keyboard::Escape:
		std::cout << "Pressed Escape" << std::endl;
		_SwitchMode(AppMode::Default);
		_SwitchTraversal(Traversal::None);
		break;

	case sf::Keyboard::C:
		std::cout << "Pressed C" << std::endl;
		_SwitchMode(AppMode::Create);
		break;

	case sf::Keyboard::M:
		std::cout << "Pressed M" << std::endl;
		_SwitchMode(AppMode::Move);
		break;

	case sf::Keyboard::Q:
		std::cout << "Pressed Q" << std::endl;
		_SwitchMode(AppMode::Connect);
		break;

	case sf::Keyboard::R:
		std::cout << "Pressed R" << std::endl;
		m_graph.Clear();
		m_currentTraversal = Traversal::None;
		break;

	case sf::Keyboard::A:
		std::cout << "Pressed A" << std::endl;
		m_graph.PrintAdjacencyMatrix();
		m_graph.PrintCostMatrix();
		m_graph.PrintAdjacencyLists();
		m_graph.PrintConnectedComponents();
		break;

	case sf::Keyboard::T:
		std::cout << "Pressed T" << std::endl;
		_SwitchMode(AppMode::Traverse);
		break;

	case sf::Keyboard::Num1:
		std::cout << "Pressed 1" << std::endl;
		_SwitchTraversal(Traversal::ShortPath);
		break;

	case sf::Keyboard::Num2:
		std::cout << "Pressed 2" << std::endl;
		_SwitchTraversal(Traversal::Prim);
		break;

	case sf::Keyboard::Num3:
		std::cout << "Pressed 3" << std::endl;
		_SwitchTraversal(Traversal::Kruskal);
		break;

	case sf::Keyboard::Num4:
		std::cout << "Pressed 4" << std::endl;
		_SwitchTraversal(Traversal::Dijkstra);
		break;

	case sf::Keyboard::Num5:
		std::cout << "Pressed 5" << std::endl;
		_SwitchTraversal(Traversal::BellmanFord);
		break;

	case sf::Keyboard::Num6:
		std::cout << "Pressed 6" << std::endl;
		_SwitchTraversal(Traversal::FloydWarshall);
		break;

	case sf::Keyboard::I:
		std::cout << "Pressed I" << std::endl;
		++m_graph.CURRENT_WEIGHT;
		break;

	case sf::Keyboard::K:
		std::cout << "Pressed K" << std::endl;
		--m_graph.CURRENT_WEIGHT;
		break;

	default:
		std::cout << "OnKeyPress >>> default" << std::endl;
		break;
	}
}

void GraphApp::_OnMouseButtonPressed(sf::Event& mouseEvent) {
	switch (mouseEvent.mouseButton.button) {
	case sf::Mouse::Left:
		_OnMouseLeft();
		break;

	case sf::Mouse::Right:
		_OnMouseRight();
		break;

	default:
		std::cout << "OnMouseButtonPressed >>> default" << std::endl;
		break;
	}
}

void GraphApp::_OnMouseButtonReleased(sf::Event& mouseEvent) {
	switch (mouseEvent.mouseButton.button) {
	case sf::Mouse::Left:
		_OnMouseLeftReleased();
		break;
	default:
		std::cout << "OnMouseButtonReleased >>> default" << std::endl;
		break;
	}
}

void GraphApp::_OnMouseLeftReleased() {
	if (m_currentMode == AppMode::Move) {
		const sf::Vector2i mouse = sf::Mouse::getPosition(m_window);
		std::cout << "Mouse Left Released (" << mouse.x << ", " << mouse.y << ")" << std::endl;
		for (auto& node : m_graph.Nodes()) {
			const int distance = static_cast<int>(sqrt((mouse.x - node.X) * (mouse.x - node.X) + (mouse.y - node.Y) * (mouse.y - node.Y)));
			if (distance <= C::NODE_SPACE && distance >= 0.0f) {
				std::cout << "Cannot move Node at (" << mouse.x << ", " << mouse.y << "). Distance is " << distance << std::endl;
				return;
			}
			else {
				m_graph.MoveNode(mouse.x, mouse.y);
			}
		}
	}
}

void GraphApp::_OnMouseMoved() {
	// const sf::Vector2i mouse = sf::Mouse::getPosition(m_window);
	// std::cout << "Mouse Moved (" << mouse.x << ", " << mouse.y << ")" << std::endl;
}

void GraphApp::_OnMouseLeft() {
	const sf::Vector2i mouse = sf::Mouse::getPosition(m_window);
	std::cout << "Mouse Left (" << mouse.x << ", " << mouse.y << ")" << std::endl;

	// Move does not work yet
	if (m_currentMode == AppMode::Move && !m_graph.Nodes().empty()) {
		for (auto& node : m_graph.Nodes()) {
			const int distance = static_cast<int>(sqrt((mouse.x - node.X) * (mouse.x - node.X) + (mouse.y - node.Y) * (mouse.y - node.Y)));
			if (distance <= C::NODE_RADIUS && distance >= 0.0f) {
				std::cout << "Clicked Node (" << node.X << ", " << node.Y << ")" << std::endl;
				m_graph.SetMoveableNode(node);
				return;
			}
		}
	}

	if (m_currentMode == AppMode::Create) {
		if (mouse.x < C::LEFT_BOUND || mouse.y < C::UPPER_BOUND || mouse.x > C::RIGHT_BOUND || mouse.y > C::LOWER_BOUND) {
			std::cout << "Cannot create Node out of bounds" << std::endl;
			return;
		}

		for (const auto& node : m_graph.Nodes()) {
			const int distance = static_cast<int>(sqrt((mouse.x - node.X) * (mouse.x - node.X) + (mouse.y - node.Y) * (mouse.y - node.Y)));
			if (distance < C::NODE_SPACE) {
				std::cout << "Cannot create Node at (" << mouse.x << ", " << mouse.y << "). Distance is " << distance << std::endl;
				return;
			}
		}

		m_graph.AddNode(mouse.x, mouse.y, static_cast<int>(sqrt(mouse.x * mouse.x + mouse.y * mouse.y)));
		std::cout << "No. of Nodes: " << m_graph.Nodes().size() << std::endl;
	}

	if (m_currentMode == AppMode::Connect) {
		for (const auto& node : m_graph.Nodes()) {
			const int distance = static_cast<int>(sqrt((mouse.x - node.X) * (mouse.x - node.X) + (mouse.y - node.Y) * (mouse.y - node.Y)));
			if (distance <= C::NODE_RADIUS && distance >= 0.0f) {
				std::cout << "Clicked Node (" << node.X << ", " << node.Y << ")" << std::endl;
				if (m_graph.EDGE_START_NODE.VALUE == C::UNITIALIZED) {
					m_graph.EDGE_START_NODE = node;
				}
				else if (m_graph.EDGE_END_NODE.VALUE == C::UNITIALIZED) {
					m_graph.EDGE_END_NODE = node;
					m_graph.MakeEdge(m_graph.EDGE_START_NODE, m_graph.EDGE_END_NODE, false, m_graph.CURRENT_WEIGHT);
					m_graph.EDGE_START_NODE = m_graph.EDGE_END_NODE = Node();
					break;
				}
			}
		}
	}

	m_graph.UpdateAdjacencyMatrix();
	m_graph.UpdateAdjacencyLists();
	m_graph.UpdateConnectedComponents();
}

void GraphApp::_OnMouseRight() {
	const sf::Vector2i mouse = sf::Mouse::getPosition(m_window);
	std::cout << "Mouse Right (" << mouse.x << ", " << mouse.y << ")" << std::endl;

	if (m_currentMode == AppMode::Create) {
		for (auto& node : m_graph.Nodes()) {
			const int distance = static_cast<int>(sqrt((mouse.x - node.X) * (mouse.x - node.X) + (mouse.y - node.Y) * (mouse.y - node.Y)));
			if (distance <= C::NODE_RADIUS && distance >= 0.0f) {
				std::cout << "Deleted Node (" << node.X << ", " << node.Y << ")" << std::endl;
				m_graph.RemoveNode(node);
				break;
			}
		}
	}

	m_graph.UpdateAdjacencyMatrix();
	m_graph.UpdateAdjacencyLists();
	m_graph.UpdateConnectedComponents();
}

void GraphApp::_SwitchMode(AppMode newMode) {
	if (m_currentMode == newMode) {
		std::cout << "Already in " << C::MODE_NAMES[static_cast<int>(newMode)] << std::endl;
		return;
	}

	std::cout << "Entered Mode " << C::MODE_NAMES[static_cast<int>(newMode)] << std::endl;
	m_currentMode = newMode;
}

void GraphApp::_SwitchTraversal(Traversal newTraversal) {
	if (m_currentTraversal == newTraversal) {
		std::cout << "Already using " << C::TRAVERSAL_NAMES[static_cast<int>(newTraversal)] << std::endl;
		return;
	}

	std::cout << "Now using " << C::TRAVERSAL_NAMES[static_cast<int>(newTraversal)] << std::endl;
	m_currentTraversal = newTraversal;
}