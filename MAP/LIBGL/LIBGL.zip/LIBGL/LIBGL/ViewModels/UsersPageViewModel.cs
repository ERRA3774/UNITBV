﻿using LIBGL.Databases;
using LIBGL.Utils;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Data;

namespace LIBGL.ViewModels
{
    public class UsersPageViewModel : ViewModelBase
    {
        private string _title;
        public string Title
        {
            get
            {
                return _title;
            }
            set
            {
                _title = value;
                OnPropertyChanged(nameof(Title));
            }
        }

        private List<Models.User> _users;
        public List<Models.User> Users
        {
            get
            {
                return _users;
            }
            set
            {
                _users = value;
                OnPropertyChanged(nameof(Users));
            }
        }

        private readonly ObservableCollection<Models.User> _allUsers;
        public ObservableCollection<Models.User> AllUsers
        {
            get => _allUsers;
            set
            {
                OnPropertyChanged(nameof(AllUsers));
            }
        }

        public ICollectionView UsersView { get; private set; }

        public UsersPageViewModel()
        {
            _title = Consts.USERS_PAGE_TITLE;
            _users = DbUtils.GetAllActiveUsers();
            _allUsers = new ObservableCollection<Models.User>(Users);
            UsersView = CollectionViewSource.GetDefaultView(_allUsers);
        }

        public void FilterUsers(string inputText)
        {
            inputText = inputText.ToLower();

            UsersView.Filter = user =>
            {
                return ((Models.User)user).FirstName.ToLower().Contains(inputText)
                || ((Models.User)user).LastName.ToLower().Contains(inputText)
                || ((Models.User)user).Email.ToLower().Contains(inputText)
                || ((Models.User)user).Phone.ToLower().Contains(inputText);
            };
        }
    }
}
