﻿using LIBGL.ViewModels;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace LIBGL.Pages
{
    public partial class BooksPage : Page
    {
        private readonly BooksPageViewModel _viewModel;
        public BooksPage()
        {
            InitializeComponent();
            _viewModel = new BooksPageViewModel();
            DataContext = _viewModel;
        }

        private void DataGridBooks_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            if (sender is not DataGrid grid || grid.SelectedItem is not Models.Book || grid.SelectedItems.Count != 1)
            {
                return;
            }

            Models.Book? selectedBook = grid.SelectedItem as Models.Book;
            DataGridBooks.UnselectAll();
            NavigationService.Navigate(ChildPage(selectedBook));
        }

        private void ButtonPlus_Click(object sender, RoutedEventArgs e)
        {
            NavigationService.Navigate(ChildPage(new Models.Book()));
        }

        private BookDetailPage ChildPage(Models.Book? book)
        {
            book ??= new Models.Book();

            BookDetailsViewModel childViewModel = new BookDetailsViewModel(_viewModel, book);
            BookDetailPage? childPage = new BookDetailPage(childViewModel);
            return childPage;
        }

        private void FilterBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (sender is not TextBox filterBox)
            {
                return;
            }

            _viewModel.FilterBooks(filterBox.Text);
        }

        private void DataGridBooks_AutoGeneratingColumn(object sender, DataGridAutoGeneratingColumnEventArgs e)
        {
            if (e.PropertyName == "BookId")
            {
                e.Cancel = true;
            }

            if (e.PropertyName == "BookTypeId")
            {
                e.Cancel = true;
            }

            if (e.PropertyName == "PublisherId")
            {
                e.Cancel = true;
            }

            if (e.PropertyName == "Stock")
            {
                e.Column.Width = 120;
            }

            if (e.PropertyName == "PublishYear")
            {
                e.Column.Width = 120;
            }

            if (e.PropertyName == "Active")
            {
                e.Cancel = true;
            }
        }
    }
}
