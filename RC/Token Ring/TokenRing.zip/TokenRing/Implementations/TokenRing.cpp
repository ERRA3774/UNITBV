#include "../Headers/TokenRing.h"

TokenRing::TokenRing() :
	Computers(std::vector<Computer>()),
	Tokens(std::queue<Token>()),
	SenderFlag(false),
	DestinationFlag(false) {}

TokenRing::TokenRing(std::initializer_list<Computer> computers, std::initializer_list<Token> tokens) :
	Computers(computers), Tokens(tokens), SenderFlag(false), DestinationFlag(false) {
	CurrentToken = Tokens.front();
}

void TokenRing::NextToken() {
	Tokens.pop();
}
