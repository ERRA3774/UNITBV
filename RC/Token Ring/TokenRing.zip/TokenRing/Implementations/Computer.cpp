#include "../Headers/Computer.h"



Computer::Computer() {
	_ip = GenerateRandomIp();
	_message = std::string();
	_hasToken = false;
}



std::string Computer::GetIp() const {
	return _ip;
}



std::string Computer::GetMessage() const {
	return _message;
}



void Computer::FetchSecretMessageFromFile(const std::string& path) {
	std::ifstream fin(path);

	if (!fin.is_open()) {
		std::clog << "[W] Computer at [ " << GetIp() << " ] could not open file from path: " << path << std::endl;
		return;
	}

	std::string fileMessage;
	while (fin) {
		std::string line;
		std::getline(fin, line);

		if (line.empty()) {
			continue;
		}

		line += '\n';
		fileMessage.append(line);
	}

	_message = fileMessage;
}



std::string Computer::GenerateRandomIp() {
	std::string ipAddress;

	for (int i = 0; i < 4; ++i) {
		int randomByte = rand() % 256;
		ipAddress += std::to_string(randomByte);
		if (i < 3) {
			ipAddress += ".";
		}
	}

	return ipAddress;
}
