#include "Edge.h"

Edge::Edge() :
	m_start({}),
	m_other({}),
	m_directed(false), 
	m_weight(0) {
	// DO NOTHING ELSE
}

Edge::Edge(Node start, Node other, bool directed, float weight) :
	m_start(start), m_other(other), m_directed(directed), m_weight(weight) {
	// DO NOTHING ELSE
}

Node Edge::Start() const {
	return m_start;
}

Node Edge::End() const {
	return m_other;
}

bool Edge::Directed() const {
	return m_directed;
}

float Edge::Weight() const {
	return m_weight;
}

void Edge::SetStart(Node& node) {
	m_start = node;
}

void Edge::SetEnd(Node& node) {
	m_other = node;
}

void Edge::SetWeight(float& weight) {
	m_weight = weight;
}

void Edge::SetDirected(bool& directed) {
	m_directed = directed;
}

bool operator==(const Edge& lhs, const Edge& rhs) {
	return lhs.Start() == rhs.Start() && lhs.End() == rhs.End();
}
