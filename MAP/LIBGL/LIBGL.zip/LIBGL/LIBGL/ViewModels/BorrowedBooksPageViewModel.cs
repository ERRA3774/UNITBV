﻿using LIBGL.Databases;
using LIBGL.Utils;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Data;

namespace LIBGL.ViewModels
{
    public class BorrowedBooksPageViewModel : ViewModelBase
    {
        private string _title;
        public string Title
        {
            get
            {
                return _title;
            }
            set
            {
                _title = value;
                OnPropertyChanged(nameof(Title));
            }
        }

        private List<Models.UserBook> _userBooks;
        public List<Models.UserBook> UserBooks
        {
            get
            {
                return _userBooks;
            }
            set
            {
                _userBooks = value;
                OnPropertyChanged(nameof(UserBooks));
            }
        }

        private List<Models.Book> _borrowedBooks;
        public List<Models.Book> BorrowedBooks
        {
            get
            {
                return _borrowedBooks;
            }
            set
            {
                _borrowedBooks = value;
                OnPropertyChanged(nameof(BorrowedBooks));
            }
        }

        private List<Models.User> _borrowerUsers;
        public List<Models.User> BorrowerUsers
        {
            get
            {
                return _borrowerUsers;
            }
            set
            {
                _borrowerUsers = value;
                OnPropertyChanged(nameof(BorrowerUsers));
            }
        }

        private readonly ObservableCollection<Models.UserBook> _allUserBooks;
        public ObservableCollection<Models.UserBook> AllUserBooks
        {
            get => _allUserBooks;
            set
            {
                OnPropertyChanged(nameof(AllUserBooks));
            }
        }

        public ICollectionView UserBooksView { get; private set; }

        public BorrowedBooksPageViewModel()
        {
            _title = Consts.BORROWED_BOOKS_PAGE_TITLE;
            _userBooks = DbUtils.GetAllActiveUserBooks();
            _borrowedBooks = DbUtils.GetBorrowedBooks();
            _borrowerUsers = DbUtils.GetBorrowerUsers();

            _allUserBooks = new ObservableCollection<Models.UserBook>(UserBooks);
            UserBooksView = CollectionViewSource.GetDefaultView(_allUserBooks);
        }

        public void FilterUserBooks(string inputText)
        {
            inputText = inputText.ToLower();

            UserBooksView.Filter = option =>
            {
                return ((Models.UserBook)option).StartDate.ToString().ToLower().Contains(inputText)
                || ((Models.UserBook)option).EndDate.ToString().ToLower().Contains(inputText)
                || ((Models.Book)option).Title.ToLower().Contains(inputText)
                || ((Models.User)option).LastName.ToLower().Contains(inputText);
            };
        }

    }
}

