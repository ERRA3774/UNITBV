﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace LIBGL.ViewModels
{
    public class PublisherDetailsViewModel : ViewModelBase
    {
        private readonly PublishersPageViewModel _parent;

        private Models.Publisher _publisher;
        public Models.Publisher Publisher
        {
            get
            {
                return _publisher;
            }
            set
            {
                _publisher = value;
                OnPropertyChanged(nameof(Publisher));
            }
        }

        private string _publisherNameBoxText;
        public string PublisherNameBoxText
        {
            get
            {
                return _publisherNameBoxText;
            }
            set
            {
                _publisherNameBoxText = value;
                OnPropertyChanged(nameof(PublisherNameBoxText));
                UpdateCanClickSaveButton();
            }
        }

        private string _addressBoxText;
        public string AddressBoxText
        {
            get
            {
                return _addressBoxText;
            }
            set
            {
                _addressBoxText = value;
                OnPropertyChanged(nameof(AddressBoxText));
                UpdateCanClickSaveButton();
            }
        }

        private bool _canClickSaveButton;
        public bool CanClickSaveButton
        {
            get { return _canClickSaveButton; }
            set
            {
                _canClickSaveButton = value;
                OnPropertyChanged(nameof(CanClickSaveButton));
            }
        }

        public PublisherDetailsViewModel(PublishersPageViewModel parent, Models.Publisher publisher)
        {
            _publisher = publisher;
            _parent = parent;
            _publisherNameBoxText = publisher.Name;
            _addressBoxText = publisher.Address;
            _canClickSaveButton = !string.IsNullOrEmpty(publisher.Name)
                && !string.IsNullOrEmpty(publisher.Address);
        }
        private void UpdateCanClickSaveButton()
        {
            CanClickSaveButton = !string.IsNullOrEmpty(PublisherNameBoxText)
                && !string.IsNullOrEmpty(AddressBoxText);
        }
    }
}
