#include "Graph.h"

Graph::Graph() :
	m_directed(false),
	m_weighted(true),
	m_nodes({}),
	m_edges({}),
	m_adjacencyMatrix({}),
	m_adjacencyLists({}),
	m_costMatrix({}) {
	// DO NOTHING ELSE
}

bool Graph::Directed() const {
	return m_directed;
}

bool Graph::Weighted() const {
	return m_weighted;
}

std::vector<Node> Graph::Nodes() const {
	return m_nodes;
}

std::vector<Edge> Graph::Edges() const {
	return m_edges;
}

Node Graph::MoveableNode() const {
	return MOVEABLE_NODE;
}

void Graph::SetMoveableNode(Node& node) {
	MOVEABLE_NODE.X = node.X;
	MOVEABLE_NODE.Y = node.Y;
	MOVEABLE_NODE.VALUE = node.VALUE;
	MOVEABLE_NODE.SELECTED = true;
}

void Graph::MoveNode(const unsigned int& x, const unsigned int& y) {
	MOVEABLE_NODE.X = x;
	MOVEABLE_NODE.Y = y;
	MOVEABLE_NODE.VALUE = static_cast<int>(sqrt(x * x + y * y));
	MOVEABLE_NODE.SELECTED = false;
}

void Graph::AddNode(const unsigned int x, const unsigned int y, const int val) {
	m_nodes.emplace_back(Node(x, y, val, false));
}

void Graph::RemoveNode(Node& node) {
	auto nodeIterator = std::remove_if(m_nodes.begin(), m_nodes.end(), [&](const Node& target) { return target == node; });
	m_nodes.erase(nodeIterator, m_nodes.end());

	auto edgeIterator = std::remove_if(m_edges.begin(), m_edges.end(), [&](const Edge& edge) { return edge.Start() == node || edge.End() == node; });
	m_edges.erase(edgeIterator, m_edges.end());
}

void Graph::MakeEdge(const Node& start, const Node& end, bool directed, float weight) {
	Edge newEdge = Edge(start, end, directed, weight);

	if (std::find_if(m_edges.begin(), m_edges.end(), [&](const Edge& target) { return target == newEdge; }) == m_edges.end()) {
		m_edges.emplace_back(newEdge);
	}
}

std::vector<Edge> Graph::Traverse(const int algorithm) {
	switch (algorithm) {
	case 0:
		m_traversal.clear();
		break;
	case 3:
		m_traversal = Kruskal();
		break;
	default:
		m_traversal.clear();
		break;
	}

	return m_traversal;
}

void Graph::PrintAdjacencyMatrix() {
	std::cout << "Adjacency Matrix: " << std::endl;
	for (size_t row = 0; row < m_adjacencyMatrix.size(); ++row) {
		std::cout << m_nodes[row].VALUE << ": ";
		for (size_t col = 0; col < m_adjacencyMatrix[0].size(); ++col) {
			std::cout << m_adjacencyMatrix[row][col] << ' ';
		}
		std::cout << std::endl;
	}
}

void Graph::PrintCostMatrix() {
	std::cout << "Cost Matrix: " << std::endl;
	for (size_t row = 0; row < m_costMatrix.size(); ++row) {
		for (size_t col = 0; col < m_costMatrix[0].size(); ++col) {
			std::cout << m_costMatrix[row][col] << ' ';
		}
		std::cout << std::endl;
	}
}

void Graph::PrintAdjacencyLists() {
	std::cout << "Adjacency Lists: " << std::endl;
	for (size_t nodeIdx = 0; nodeIdx < m_adjacencyLists.size(); ++nodeIdx) {
		std::cout << "L[" << m_nodes[nodeIdx].VALUE << "]: ";
		for (int neighbor : m_adjacencyLists[nodeIdx]) {
			std::cout << m_nodes[neighbor].VALUE << " ";
		}
		std::cout << std::endl;
	}
}

void Graph::PrintConnectedComponents() {
	std::cout << "Connected Components: " << std::endl;
	for (size_t compIdx = 0; compIdx < m_connectedComponents.size(); ++compIdx) {
		std::cout << "C[" << compIdx << "]: ";
		for (size_t nodeIdx = 0; nodeIdx < m_connectedComponents[compIdx].size(); ++nodeIdx) {
			std::cout << m_connectedComponents[compIdx][nodeIdx].VALUE << " ";
		}
		std::cout << std::endl;
	}
}

void Graph::Clear() {
	m_nodes.clear();
	m_edges.clear();
	m_adjacencyMatrix.clear();
	m_adjacencyLists.clear();
	m_costMatrix.clear();
	m_connectedComponents.clear();
	MOVEABLE_NODE = EDGE_START_NODE = EDGE_END_NODE = Node();
	CURRENT_WEIGHT = C::UNITIALIZED_WEIGHT;
}

void Graph::UpdateAdjacencyMatrix() {
	m_adjacencyMatrix.clear();
	m_costMatrix.clear();

	if (m_nodes.empty()) {
		return;
	}

	for (size_t row = 0; row < m_nodes.size(); ++row) {
		m_adjacencyMatrix.emplace_back(std::vector<bool>(m_nodes.size(), 0));
		m_costMatrix.emplace_back(std::vector<float>(m_nodes.size(), 9));
		m_costMatrix[row][row] = 0;
	}

	if (m_edges.empty()) {
		return;
	}

	for (const auto& edge : m_edges) {
		size_t startIdx = _IndexOf(edge.Start());
		size_t endIdx = _IndexOf(edge.End());

		if (startIdx < m_nodes.size() && endIdx < m_nodes.size()) {
			m_adjacencyMatrix[startIdx][endIdx] = true;
			m_adjacencyMatrix[startIdx][endIdx] = true;

			m_costMatrix[startIdx][endIdx] = edge.Weight();
			m_costMatrix[startIdx][endIdx] = edge.Weight();
		}
	}
}

void Graph::UpdateAdjacencyLists() {
	m_adjacencyLists.clear();

	if (m_nodes.empty() || m_edges.empty()) {
		return;
	}

	m_adjacencyLists.resize(m_nodes.size());

	for (const auto& edge : m_edges) {
		size_t startIdx = _IndexOf(edge.Start());
		size_t endIdx = _IndexOf(edge.End());

		if (startIdx < m_nodes.size() && endIdx < m_nodes.size()) {
			m_adjacencyLists[startIdx].emplace_back(endIdx);
		}
	}
}

void Graph::UpdateConnectedComponents() {
	m_connectedComponents.clear();

	if (m_nodes.empty() || m_edges.empty()) {
		return;
	}

	std::vector<bool> visited(m_nodes.size(), false);

	for (size_t i = 0; i < m_nodes.size(); ++i) {
		if (!visited[i]) {
			std::vector<Node> component;
			_DFS(i, visited, component);
			m_connectedComponents.emplace_back(component);
		}
	}
}

std::vector<Edge> Graph::Kruskal() {

	if (m_directed) {
		// throw "Graph is directed";
		std::cout << "Graph::Kruskal >>> Graph is directed." << std::endl;
		return {};
	}

	if (!m_weighted) {
		//throw "Graph is not weighted";
		std::cout << "Graph::Kruskal >>> Graph is NOT weighted." << std::endl;
		return {};
	}

	if (m_nodes.size() < 2) {
		//throw "Graph has less than 2 nodes.";
		std::cout << "Graph::Kruskal >>> Graph is has less than 2 nodes." << std::endl;
		return {};
	}

	if (m_connectedComponents.size() != 1) {
		//throw "Graph is not connected";
		std::cout << "Graph::Kruskal >>> Graph is NOT connected." << std::endl;
		return {};
	}

	std::sort(m_edges.begin(), m_edges.end(), [&](const Edge& e1, const Edge& e2) { return e1.Weight() < e2.Weight(); }); // O(e log e) | e = no. of edges

	std::vector<Edge> kruskalMST; // O(1)
	std::vector<Node> components(m_nodes.size()); // O(n) | n = no. of nodes

	for (const auto& node : m_connectedComponents[0]) { // O(n) | n = no. of edges
		components[_IndexOf(node)] = node;
	}

	for (const auto& edge : m_edges) { // O(e) | e = no. of edges
		size_t startIdx = _IndexOf(edge.Start()); 
		size_t endIdx = _IndexOf(edge.End()); 

		if (components[startIdx] != components[endIdx]) { // O(log n) 
			kruskalMST.emplace_back(edge);

			Node oldComponentNode = components[endIdx];
			Node newComponentNode = components[startIdx];

			for (size_t i = 0; i < m_nodes.size(); ++i) { // O(e log n)
				if (components[i] == oldComponentNode) {
					components[i] = newComponentNode;
				}
			}
		}
	}

	// Complexity: O(e log n) | e = no. of edges n = no.of nodes

	return kruskalMST;
}

size_t Graph::_IndexOf(const Node& node) const {
	auto it = std::find(m_nodes.begin(), m_nodes.end(), node); 

	if (it != m_nodes.end()) {
		return std::distance(m_nodes.begin(), it);
	}

	return std::numeric_limits<size_t>::max();
}

void Graph::_DFS(size_t nodeIndex, std::vector<bool>& visited, std::vector<Node>& component) {
	std::stack<size_t> stack;
	stack.push(nodeIndex);
	visited[nodeIndex] = true;

	while (!stack.empty()) {
		size_t current = stack.top();
		stack.pop();
		component.push_back(m_nodes[current]);

		for (const auto& neighbor : _Neighbors(current)) {
			size_t neighborIndex = _IndexOf(neighbor);

			if (!visited[neighborIndex]) {
				stack.push(neighborIndex);
				visited[neighborIndex] = true;
			}
		}
	}
}

std::vector<Node> Graph::_Neighbors(size_t nodeIndex) const {
	std::vector<Node> neighbors;

	for (const auto& edge : m_edges) {
		if (_IndexOf(edge.Start()) == nodeIndex) {
			neighbors.push_back(edge.End());
		}
		else if (_IndexOf(edge.End()) == nodeIndex) {
			neighbors.push_back(edge.Start());
		}
	}

	return neighbors;
}