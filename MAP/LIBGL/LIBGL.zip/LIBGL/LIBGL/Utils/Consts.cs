﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LIBGL.Utils
{
    public class Consts
    {
        // Start: Strings
        public static readonly string HOME_PAGE_TITLE = "Home Page";

        public static readonly string DASHBOARD_PAGE_TITLE = "Dashboard Page";

        public static readonly string USERS_PAGE_TITLE = "Users Page";

        public static readonly string PUBLISHERS_PAGE_TITLE = "Publishers Page";

        public static readonly string BOOKS_PAGE_TITLE = "Books Page";

        public static readonly string AUTHORS_PAGE_TITLE = "Authors Page";

        public static readonly string GENRES_PAGE_TITLE = "Genres Page";

        public static readonly string BORROWED_BOOKS_PAGE_TITLE = "Borrowed Books Page";

        public static readonly string COMING_SOON_TEXT = "Coming soon";
        // End: Strings

        // Start: Strings
        public static readonly string AUTHOR_ADD_TEXT = "Add Author";

        public static readonly string USER_ADD_TEXT = "Add User";

        public static readonly string BOOK_ADD_TEXT = "Add Book";

        public static readonly string PUBLISHER_ADD_TEXT = "Add Publisher";

        public static readonly string AUTHOR_BOOK_ADD_TEXT = "Add AuthorBook";

        public static readonly string BOOK_TYPE_ADD_TEXT = "Add Genre";

        public static readonly string USER_BOOK_ADD_TEXT = "Add User Book";

        // End: Strings


        // Start: Stored Procedures
        public static readonly string AUTHOR_INSERT = "spAuthorInsert";
        public static readonly string AUTHOR_UPDATE = "spAuthorUpdate";
        public static readonly string AUTHOR_SELECT = "spAuthorSelect";
        public static readonly string AUTHOR_DELETE = "spAuthorDelete";
        public static readonly string AUTHOR_ALL_SELECT = "spAllAuthorsSelect";
        public static readonly string AUTHOR_ALL_ACTIVE_SELECT = "spAllActiveAuthorsSelect";

        public static readonly string USER_INSERT = "spUserInsert";
        public static readonly string USER_UPDATE = "spUserUpdate";
        public static readonly string USER_SELECT = "spUserSelect";
        public static readonly string USER_DELETE = "spUserDelete";
        public static readonly string USER_ALL_SELECT = "spAllUsersSelect";
        public static readonly string USER_ALL_ACTIVE_SELECT = "spAllActiveUsersSelect";

        public static readonly string BOOK_INSERT = "spBookInsert";
        public static readonly string BOOK_UPDATE = "spBookUpdate";
        public static readonly string BOOK_SELECT = "spBookSelect";
        public static readonly string BOOK_DELETE = "spBookDelete";
        public static readonly string BOOK_ALL_SELECT = "spAllBooksSelect";
        public static readonly string BOOK_ALL_ACTIVE_SELECT = "spAllActiveBooksSelect";
        public static readonly string BOOK_AUTHOR_SELECT = "spBookAuthorSelect";

        public static readonly string PUBLISHER_INSERT = "spPublisherInsert";
        public static readonly string PUBLISHER_UPDATE = "spPublisherUpdate";
        public static readonly string PUBLISHER_SELECT = "spPublisherSelect";
        public static readonly string PUBLISHER_DELETE = "spPublisherDelete";
        public static readonly string PUBLISHER_ALL_ACTIVE_SELECT = "spAllActivePublishersSelect";
        public static readonly string PUBLISHER_ALL_SELECT = "spAllPublishersSelect";

        public static readonly string AUTHOR_BOOK_INSERT = "spAuthorBookInsert";
        public static readonly string AUTHOR_BOOK_UPDATE = "spAuthorBookUpdate";
        public static readonly string AUTHOR_BOOK_SELECT = "spAuthorBookSelect";
        public static readonly string AUTHOR_BOOK_DELETE = "spAuthorBookDelete";
        public static readonly string AUTHOR_BOOK_ALL_ACTIVE_SELECT = "spAllActiveAuthorBookSelect";
        public static readonly string AUTHOR_BOOK_ALL_SELECT = "spAllAuthorBookSelect";

        public static readonly string BOOK_TYPE_INSERT = "spBookTypeInsert";
        public static readonly string BOOK_TYPE_UPDATE = "spBookTypeUpdate";
        public static readonly string BOOK_TYPE_SELECT = "spBookTypeSelect";
        public static readonly string BOOK_TYPE_DELETE = "spBookTypeDelete";
        public static readonly string BOOK_TYPE_ALL_ACTIVE_SELECT = "spAllActiveBookTypeSelect";
        public static readonly string BOOK_TYPE_ALL_SELECT = "spAllBookTypeSelect";

        public static readonly string USER_BOOK_INSERT = "spUserBookInsert";
        public static readonly string USER_BOOK_UPDATE = "spUserBookUpdate";
        public static readonly string USER_BOOK_SELECT = "spUserBookSelect";
        public static readonly string USER_BOOK_DELETE = "spUserBookDelete";
        public static readonly string USER_BOOK_ALL_ACTIVE_SELECT = "spAllActiveUserBookSelect";
        public static readonly string USER_BOOK_ALL_SELECT = "spAllUserBookSelect";

        // End: Stored Procedures

        // Start: Images
        public static readonly string AUTHOR_CARD = "../Resources/author.png";
        public static readonly string AUTHOR_PORTRAIT = "../Resources/authorportrait.png";

        public static readonly string BOOK_CARD = "../Resources/book.png";
        public static readonly string BOOK_PORTRAIT = "../Resources/bookportrait.png";

        public static readonly string FALLBACK_CARD = "../Resources/fallback.png";
        public static readonly string FALLBACK_PORTRAIT = "../Resources/fallbackportrait.png";

        public static readonly string GENRE_CARD = "../Resources/genre.png";
        public static readonly string GENRE_PORTRAIT = "../Resources/genreportrait.png";

        public static readonly string PUBLISHER_CARD = "../Resources/publisher.png";
        public static readonly string PUBLISHER_PORTRAIT = "../Resources/publisherportrait.png";

        public static readonly string USER_CARD = "../Resources/user.png";
        public static readonly string USER_PORTRAIT = "../Resources/userportrait.png";
        // End: Images

        public static readonly string ELLIPSES = "...";
        public static readonly string FALLBACK_TEXT = "➕";
        public static readonly string ADD_TEXT = "Add";
        public static readonly string SAVE_TEXT = "Save";
        public static readonly string CANCEL_TEXT = "Cancel";

        public static readonly int MAX_LENGTH_CARD_TEXT = 10;
        public static readonly int PAGE_CARDS_COUNT = 10;
        public static readonly int LENGTH_TRUNCATED_CARD_TEXT = 7;
        public static readonly int TEXTBOX_PRIMARY_LIMIT = 50;
        public static readonly int TEXTBOX_SECONDARY_LIMIT = 10;
        public static readonly int TEXTBOX_TERTIARY_LIMIT = 5;
    }
}
