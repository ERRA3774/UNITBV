﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LIBGL.Models
{
    public class UserBook
    {
        public int Id { get; set; }
        public int UserId { get; set; }
        public int BookId { get; set; }
        public DateOnly StartDate { get; set; }
        public DateOnly EndDate { get; set; }
        public bool Active { get; set; }

        public UserBook()
        {
            Id = int.MinValue;
            UserId = int.MinValue;
            BookId = int.MinValue;
            StartDate = new DateOnly();
            EndDate = new DateOnly();
            Active = false;
        }
    }
}
