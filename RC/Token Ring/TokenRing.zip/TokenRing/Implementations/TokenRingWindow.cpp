#include "../Headers/TokenRingWindow.h"

TokenRingWindow::TokenRingWindow() {}

void TokenRingWindow::OnCreate() {

	// Initialization
	//--------------------------------------------------------------------------------------
	InitWindow(SCREEN_WIDTH, SCREEN_HEIGHT, "Token Ring Network Visualization");


	srand(static_cast<unsigned>(time(NULL)));
	bool paused = false;
	bool senderCollision = false;
	bool destinationCollision = false;

	float moonAngle = 0.0f;
	float starAngle = 0.0f;

	int textSize = MeasureText(LOG_TEXT, PRIMARY_FONT_SIZE);
	int textGuiX = GUI_RECT_X + textSize / static_cast<float>(2);

	int stateTextY = GUI_RECT_Y + 50;

	int senderLabelY = GUI_RECT_Y + 140;
	int senderTextY = senderLabelY + 50;

	int destinationLabelY = GUI_RECT_Y + 240;
	int destinationTextY = destinationLabelY + 50;

	int compALabelY = GUI_RECT_Y + 360;
	int compATextY = compALabelY + 30;

	int compBLabelY = GUI_RECT_Y + 420;
	int compBTextY = compBLabelY + 30;

	int compCLabelY = GUI_RECT_Y + 480;
	int compCTextY = compCLabelY + 30;

	int compDLabelY = GUI_RECT_Y + 540;
	int compDTextY = compDLabelY + 30;

	int compELabelY = GUI_RECT_Y + 600;
	int compETextY = compELabelY + 30;

	int compFLabelY = GUI_RECT_Y + 660;
	int compFTextY = compFLabelY + 30;

	const char* stateText = SEARCHING_STATE_TEXT;

	double previousTime = GetTime();

	std::vector<Vector2> starPositions;

	for (int i = 0; i < STARS_COUNT; i++) {
		starPositions.push_back({ static_cast<float>(rand() % 1100), static_cast<float>(rand() % 1000) });
	}

	Color currentMoon = SILVER_MOON;

	Image earth = LoadImage(EARTH_IMG);
	Texture2D earthTexture = LoadTextureFromImage(earth);
	UnloadImage(earth);
	const float earthTextureX = EARTH_X - earthTexture.width / static_cast<float>(2);
	const float earthTextureY = EARTH_Y - earthTexture.height / static_cast<float>(2);

	Image moon = LoadImage(MOON_IMG);
	Texture2D moonTexture = LoadTextureFromImage(moon);
	UnloadImage(moon);

	Image satAImage = LoadImage(SAT_A_IMG);
	Texture2D satATexture = LoadTextureFromImage(satAImage);
	UnloadImage(satAImage);
	const float satATextureX = SAT_A_X - satATexture.width / static_cast<float>(2);
	const float satATextureY = SAT_A_Y - satATexture.height / static_cast<float>(2);

	Image satBImage = LoadImage(SAT_B_IMG);
	Texture2D satBTexture = LoadTextureFromImage(satBImage);
	UnloadImage(satBImage);

	const float satBTextureX = SAT_B_X - satBTexture.width / static_cast<float>(2);
	const float satBTextureY = SAT_B_Y - satBTexture.height / static_cast<float>(2);

	Image satCImage = LoadImage(SAT_C_IMG);
	Texture2D satCTexture = LoadTextureFromImage(satCImage);
	UnloadImage(satCImage);

	const float satCTextureX = SAT_C_X - satCTexture.width / static_cast<float>(2);
	const float satCTextureY = SAT_C_Y - satCTexture.height / static_cast<float>(2);

	Image satDImage = LoadImage(SAT_D_IMG);
	Texture2D satDTexture = LoadTextureFromImage(satDImage);
	UnloadImage(satDImage);

	const float satDTextureX = SAT_D_X - satDTexture.width / static_cast<float>(2);
	const float satDTextureY = SAT_D_Y - satDTexture.height / static_cast<float>(2);

	Image satEImage = LoadImage(SAT_E_IMG);
	Texture2D satETexture = LoadTextureFromImage(satEImage);
	UnloadImage(satEImage);

	const float satETextureX = SAT_E_X - satETexture.width / static_cast<float>(2);
	const float satETextureY = SAT_E_Y - satETexture.height / static_cast<float>(2);

	Image satFImage = LoadImage(SAT_F_IMG);
	Texture2D satFTexture = LoadTextureFromImage(satFImage);
	UnloadImage(satFImage);
	const float satFTextureX = SAT_F_X - satFTexture.width / static_cast<float>(2);
	const float satFTextureY = SAT_F_Y - satFTexture.height / static_cast<float>(2);

	Rectangle netContainer = {
		NET_RECT_X,
		NET_RECT_Y,
		NET_RECT_WIDTH,
		NET_RECT_HEIGHT,
	};

	Rectangle guiContainer = {
		GUI_RECT_X,
		GUI_RECT_Y,
		GUI_RECT_WIDTH,
		GUI_RECT_HEIGHT
	};

	Rectangle satA = {
		SAT_A_X,
		SAT_A_Y,
		satATexture.width,
		satATexture.height
	};

	Rectangle satB = {
		SAT_B_X,
		SAT_B_Y,
		satBTexture.width,
		satBTexture.height
	};

	Rectangle satC = {
		SAT_C_X,
		SAT_C_Y,
		satCTexture.width,
		satCTexture.height
	};

	Rectangle satD = {
		SAT_D_X,
		SAT_D_Y,
		satDTexture.width,
		satDTexture.height
	};

	Rectangle satE = {
		SAT_E_X,
		SAT_E_Y,
		satETexture.width,
		satETexture.height
	};

	Rectangle satF = {
		SAT_F_X,
		SAT_F_Y,
		satFTexture.width,
		satFTexture.height
	};

	Rectangle currentSender = {
		0.0f,
		0.0f,
		0.0f,
		0.0f
	};

	Rectangle currentDestination = {
		0.0f,
		0.0f,
		0.0f,
		0.0f
	};



	Computer compA;
	Computer compB;
	Computer compC;
	Computer compD;
	Computer compE;
	Computer compF;

	compA.FetchSecretMessageFromFile(SAT_A_MSG);
	compB.FetchSecretMessageFromFile(SAT_B_MSG);
	compC.FetchSecretMessageFromFile(SAT_C_MSG);
	compD.FetchSecretMessageFromFile(SAT_D_MSG);
	compE.FetchSecretMessageFromFile(SAT_E_MSG);
	compF.FetchSecretMessageFromFile(SAT_F_MSG);

	Token token1(compC.GetIp(), compE.GetIp(), compC.GetMessage());
	Token token2(compF.GetIp(), compB.GetIp(), compF.GetMessage());
	Token token3(compA.GetIp(), compD.GetIp(), compA.GetMessage());
	Token token4(compE.GetIp(), compA.GetIp(), compE.GetMessage());
	Token token5(compB.GetIp(), compC.GetIp(), compB.GetMessage());
	Token token6(compD.GetIp(), compF.GetIp(), compA.GetMessage());

	std::initializer_list<Computer> computers = { compA, compB, compC, compD, compE, compF };
	std::initializer_list<Token> tokens = { token1, token2, token3, token4, token5, token6 };

	TokenRing network(computers, tokens);

	std::unordered_map<std::string, Rectangle> Satellites;

	Satellites[compA.GetIp()] = satA;
	Satellites[compB.GetIp()] = satB;
	Satellites[compC.GetIp()] = satC;
	Satellites[compD.GetIp()] = satD;
	Satellites[compE.GetIp()] = satE;
	Satellites[compF.GetIp()] = satF;

	SetTargetFPS(144);               // Run at 144 frames-per-second
	//--------------------------------------------------------------------------------------

	// Main game loop
	while (!WindowShouldClose())    // Detect window close button or ESC key
	{
		// Update
		//----------------------------------------------------------------------------------



		// Input
		switch (GetKeyPressed()) {
		case KEY_SPACE:
			paused = !paused;
			break;
		default:
			break;
		}

		// Input



		// Delta Time
		double currentTime = GetTime();
		double deltaTime = currentTime - previousTime;
		previousTime = currentTime;
		// Delta Time



		// Stars positions
		starAngle += STEP_UNIT * deltaTime;
		for (Vector2& star : starPositions) {
			star.x += 0.1f * cosf(starAngle);
			star.y += 0.1f * sinf(starAngle);
		}
		//


		// Moon orbit
		Vector2 moonPosition{};
		moonPosition.x = EARTH_X + MOON_DISTANCE * cosf(moonAngle);
		moonPosition.y = EARTH_Y + MOON_DISTANCE * sinf(moonAngle);

		if (!paused) {
			moonAngle += STEP_UNIT * deltaTime;
		}

		Rectangle moonBounds = { moonPosition.x, moonPosition.y, moonTexture.width, moonTexture.height };
		// Moon orbit


		// Token Ring
		if (network.SenderFlag == false) {
			currentSender = Satellites[network.CurrentToken.Sender];
			currentDestination = Satellites[network.CurrentToken.Destination];
		}

		if (CheckCollisionRecs(moonBounds, currentSender) && network.SenderFlag == false) {
			std::cout << "Satellite " << network.CurrentToken.Sender << " wants to send message to " << network.CurrentToken.Destination << std::endl;
			std::cout << "The message reads: " << network.CurrentToken.Message << std::endl;
			currentMoon = BLOOD_MOON;
			network.SenderFlag = true;
			stateText = SENDING_STATE_TEXT;
		}

		if (CheckCollisionRecs(moonBounds, currentDestination) && network.SenderFlag == true && network.DestinationFlag == false) {
			std::cout << "Satellite " << network.CurrentToken.Destination << " received the message from " << network.CurrentToken.Sender << std::endl;
			std::cout << "The message reads: " << network.CurrentToken.Message << std::endl;
			currentMoon = BLUE_MOON;
			network.DestinationFlag = true;
			stateText = RETURNING_STATE_TEXT;
		}

		if (CheckCollisionRecs(moonBounds, currentSender) && network.SenderFlag == true && network.DestinationFlag == true) {
			network.SenderFlag = false;
			network.DestinationFlag = false;

			std::cout << "Sattelite " << network.CurrentToken.Sender << " received the confirmation.\n" << std::endl;
			network.NextToken();
			if (network.Tokens.empty()) {
				network.Tokens = std::queue<Token>(tokens);
			}
			network.CurrentToken = network.Tokens.front();
			currentMoon = SILVER_MOON;
			stateText = SEARCHING_STATE_TEXT;
		}

		//----------------------------------------------------------------------------------


		// Draw
		//----------------------------------------------------------------------------------
		BeginDrawing();

		ClearBackground(RAYWHITE);

		// Containers
		DrawRectangleRounded(netContainer, 0.01f, NULL, SPACE_VOID);
		DrawRectangleRounded(guiContainer, 0.01f, NULL, PRIMARY_BLUE);

		for (Vector2& star : starPositions) {
			DrawPixelV(star, WHITE);
		}

		// Earth and moon
		DrawTexture(earthTexture, earthTextureX, earthTextureY, SKYBLUE);
		DrawTexture(moonTexture, moonPosition.x - moonTexture.width / static_cast<float>(2), moonPosition.y - moonTexture.height / static_cast<float>(2), currentMoon);


		// Satellites
		DrawTexture(satATexture, satATextureX, satATextureY, LIGHTGRAY);
		DrawTexture(satBTexture, satBTextureX, satBTextureY, LIGHTGRAY);
		DrawTexture(satCTexture, satCTextureX, satCTextureY, LIGHTGRAY);
		DrawTexture(satDTexture, satDTextureX, satDTextureY, LIGHTGRAY);
		DrawTexture(satETexture, satETextureX, satETextureY, LIGHTGRAY);
		DrawTexture(satFTexture, satFTextureX, satFTextureY, LIGHTGRAY);



		// GUI

		DrawText(stateText, textGuiX, stateTextY, PRIMARY_FONT_SIZE, SILVER_MOON);

		DrawText(SENDER_LABEL_TEXT, textGuiX, senderLabelY, SECONDARY_FONT_SIZE, PRIMARY_BROWN);
		DrawText(network.CurrentToken.Sender.data(), textGuiX, senderTextY, TERTIARY_FONT_SIZE, SECONDARY_BROWN);

		DrawText(DESTINATION_LABEL_TEXT, textGuiX, destinationLabelY, SECONDARY_FONT_SIZE, PRIMARY_BROWN);
		DrawText(network.CurrentToken.Destination.data(), textGuiX, destinationTextY, TERTIARY_FONT_SIZE, SECONDARY_BROWN);

		DrawText(COMP_A_LABEL_TEXT, textGuiX, compALabelY, TERTIARY_FONT_SIZE, PRIMARY_BROWN);
		DrawText(compA.GetIp().data(), textGuiX, compATextY, QUARTERNARY_FONT_SIZE, SECONDARY_BROWN);

		DrawText(COMP_B_LABEL_TEXT, textGuiX, compBLabelY, TERTIARY_FONT_SIZE, PRIMARY_BROWN);
		DrawText(compB.GetIp().data(), textGuiX, compBTextY, QUARTERNARY_FONT_SIZE, SECONDARY_BROWN);

		DrawText(COMP_C_LABEL_TEXT, textGuiX, compCLabelY, TERTIARY_FONT_SIZE, PRIMARY_BROWN);
		DrawText(compC.GetIp().data(), textGuiX, compCTextY, QUARTERNARY_FONT_SIZE, SECONDARY_BROWN);

		DrawText(COMP_D_LABEL_TEXT, textGuiX, compDLabelY, TERTIARY_FONT_SIZE, PRIMARY_BROWN);
		DrawText(compD.GetIp().data(), textGuiX, compDTextY, QUARTERNARY_FONT_SIZE, SECONDARY_BROWN);

		DrawText(COMP_E_LABEL_TEXT, textGuiX, compELabelY, TERTIARY_FONT_SIZE, PRIMARY_BROWN);
		DrawText(compE.GetIp().data(), textGuiX, compETextY, QUARTERNARY_FONT_SIZE, SECONDARY_BROWN);

		DrawText(COMP_F_LABEL_TEXT, textGuiX, compFLabelY, TERTIARY_FONT_SIZE, PRIMARY_BROWN);
		DrawText(compF.GetIp().data(), textGuiX, compFTextY, QUARTERNARY_FONT_SIZE, SECONDARY_BROWN);

		DrawFPS(5, 5);

		EndDrawing();
		//----------------------------------------------------------------------------------
	}

	// De-Initialization
	//--------------------------------------------------------------------------------------
	CloseWindow();
	//--------------------------------------------------------------------------------------

}