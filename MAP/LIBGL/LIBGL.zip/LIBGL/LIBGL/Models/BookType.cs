﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LIBGL.Models
{
    public class BookType
    {
        public int BookTypeId { get; set; }
        public string Name { get; set; }
        public bool Active { get; set; }

        public BookType()
        {
            BookTypeId = int.MinValue;
            Name = string.Empty;
            Active = false;
        }
    }
}
